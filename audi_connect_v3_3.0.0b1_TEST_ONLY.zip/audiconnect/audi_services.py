from __future__ import annotations

import asyncio
import base64
import hmac
import json
import logging
import os
import re
import uuid
from datetime import datetime, timedelta, UTC
from hashlib import sha256, sha512
from typing import Any, NoReturn
from urllib.parse import parse_qs, urlencode, urlparse

from aiohttp import ClientResponseError
from bs4 import BeautifulSoup

from .audi_api import AudiAPI
from .api_probe import run_read_only_probes
from .capability_jobs import (
    BASE_SELECTIVE_JOBS,
    capability_snapshot,
    observed_readable_jobs,
    select_jobs,
)
from .audi_models import TripDataResponse, VehicleDataResponse, VehiclesResponse
from .const import AUTH0_REDIRECT_URI, AUTH0_REFRESH_TOKEN_PREFIX, DEFAULT_API_LEVEL
from .util import get_attr, to_byte_array

MAX_RESPONSE_ATTEMPTS = 10
REQUEST_STATUS_SLEEP = 10

# The home-region lookup can return a ha-5a.prd.<region>.vwg.vwautocloud.net base
# URI. That host does not present a usable certificate chain, so every call routed
# there dies with CERTIFICATE_VERIFY_FAILED. Anything containing this is discarded
# in favour of the static default.
UNUSABLE_HOME_REGION_HOST = "vwautocloud"

# Charging start/stop confirmation. Kept short because each poll spends one
# call from the metered daily allowance and blocks the service call.
CHARGING_CONFIRM_ATTEMPTS = 3
CHARGING_CONFIRM_SLEEP = 5

# Climatisation needs a longer window than charging. Measured on a live vehicle
# 2026-09-13: a start the car never acted on sat at in_progress through +10s and
# +20s and only reached "timeout" at about +60s, so the 15s charging budget would
# expire before the failure was visible and report it as merely unconfirmed.
CLIMATISATION_CONFIRM_ATTEMPTS = 8
CLIMATISATION_CONFIRM_SLEEP = 10


# The settings the car round-trips. Anything outside this set is rejected rather
# than sent, so a typo becomes an error here instead of a field the car ignores.
_CLIMATISATION_SETTING_FIELDS = frozenset(
    {
        "targetTemperature",
        "targetTemperature_C",
        "targetTemperature_F",
        "targetTemperatureUnit",
        "climatisationWithoutExternalPower",
        "climatizationAtUnlock",
        "windowHeatingEnabled",
        "heaterSource",
        "zoneFrontLeftEnabled",
        "zoneFrontRightEnabled",
        "zoneRearLeftEnabled",
        "zoneRearRightEnabled",
    }
)


def build_climatisation_settings_update(value: dict, **changes: Any) -> dict:
    """Pure read-modify-write core for the climatisation settings.

    `value` is climatisation.climatisationSettings.value as the car reports it.
    Returns the body for PUT climatisation/settings: every field the car gave
    back, with the named ones changed.

    Read-modify-write for the same reason the charging profile write is: the
    endpoint takes the whole object, so sending one field would drop the rest.
    A toggle of a heated seat must not clear the target temperature or the
    heater source.

    carCapturedTimestamp is dropped. It is the server describing when it last
    observed the settings, not a setting, and echoing it back is meaningless at
    best.
    """
    if not isinstance(value, dict) or not value:
        raise ValueError("No climatisation settings to update")

    unknown = set(changes) - set(_CLIMATISATION_SETTING_FIELDS)
    if unknown:
        raise ValueError(f"Not climatisation settings: {sorted(unknown)}")

    body = {k: v for k, v in value.items() if k != "carCapturedTimestamp"}
    body.update(changes)
    return body


def build_profile_update(value: dict, profile_id, target_soc: int) -> tuple[int, dict]:
    """Pure read-modify-write core for a location charging profile.

    `value` is chargingProfiles.chargingProfilesStatus.value as the car reports
    it. Returns (resolved_profile_id, put_body) where put_body is exactly what
    goes on the wire: {"profile": <the whole profile, one field changed>}.

    Kept pure and module-level so the field-preservation and profile-selection
    logic is testable against a real payload without standing up the service.
    """
    if not (20 <= target_soc <= 100):
        raise ValueError("Target state of charge must be between 20 and 100 percent")

    profiles = (value or {}).get("profiles") or []
    if profile_id is None:
        profile_id = (value or {}).get("vehiclePositionedInProfileID")
    profile = next((p for p in profiles if p.get("id") == profile_id), None)
    if profile is None:
        present = [p.get("id") for p in profiles]
        raise ValueError(
            f"No charging profile with id {profile_id} (present: {present})"
        )

    # Change exactly one field; round-trip the rest, position included.
    updated = dict(profile)
    updated["targetSOC_pct"] = target_soc
    return profile_id, {"profile": updated}


# Fields the start body carries straight over from the car's stored settings.
# Only those the car actually reports are sent: a vehicle with no rear zones
# never receives zoneRear* keys, which is also the shape the myAudi app sends.
_START_PASSTHROUGH = (
    "climatisationWithoutExternalPower",
    "climatizationAtUnlock",
    "windowHeatingEnabled",
    "zoneFrontLeftEnabled",
    "zoneFrontRightEnabled",
    "zoneRearLeftEnabled",
    "zoneRearRightEnabled",
    "heaterSource",
)

# Caller parameter -> the field it overrides in the start body.
_START_OVERRIDES = {
    "climatisation_at_unlock": "climatizationAtUnlock",
    "glass_heating": "windowHeatingEnabled",
    "seat_fl": "zoneFrontLeftEnabled",
    "seat_fr": "zoneFrontRightEnabled",
    "seat_rl": "zoneRearLeftEnabled",
    "seat_rr": "zoneRearRightEnabled",
}

# What the start body was built from before it read the car's settings (2.4.0).
# Used only when the car reports no climatisationSettings at all (#873): there is
# nothing stored to preserve then, and refusing to start leaves no way to start
# climatisation with any settings from Home Assistant.
_START_DEFAULTS = {
    "climatisationWithoutExternalPower": True,
    "climatizationAtUnlock": False,
    "windowHeatingEnabled": False,
    "zoneFrontLeftEnabled": False,
    "zoneFrontRightEnabled": False,
    "zoneRearLeftEnabled": False,
    "zoneRearRightEnabled": False,
}


def build_climatisation_start_body(settings: dict, **params: Any) -> dict:
    """Pure read-modify-write core for climatisation/start.

    `settings` is climatisation.climatisationSettings.value as the car reports
    it. Returns the body for POST climatisation/start: the car's own settings,
    with only the parameters the caller actually supplied changed.

    Built this way because the endpoint REPLACES rather than merges. The
    previous body was assembled from constants, so every parameter the caller
    omitted went out as bool(None), which is False. Starting climatisation from
    the climate entity, which passes only a target temperature, therefore wiped
    the stored window heating, every seat zone and climatisation-at-unlock.
    Found on a live vehicle 2026-09-12: the myAudi app's own start kept those
    settings and ours cleared them, on the same car minutes apart.

    A parameter left as None means "leave whatever the car has", never False.

    Some cars report the climatisation status but no settings at all (#873, a
    2024 Q8 Sportback e-tron: selectivestatus has no climatisationSettings).
    Then there is nothing to preserve, so the body is built from the defaults
    the start used before this became a read-modify-write, and an unsupplied
    parameter means False again. Raising here instead made every start with
    settings fail before anything was sent.
    """
    if not isinstance(settings, dict) or not settings:
        settings = dict(_START_DEFAULTS)

    body: dict[str, Any] = {
        key: settings[key] for key in _START_PASSTHROUGH if key in settings
    }

    temp_f = params.get("temp_f")
    temp_c = params.get("temp_c")
    if temp_f is not None:
        target: Any = int((temp_f - 32) * (5 / 9))
    elif temp_c is not None:
        target = int(temp_c)
    else:
        # Unchanged, so pass the car's own value through rather than rounding
        # it: the car stores half degrees and we were not asked to touch this.
        target = settings.get("targetTemperature_C")
    body["targetTemperature"] = 21 if target is None else target
    body["targetTemperatureUnit"] = "celsius"

    # Unchanged from before this became a read-modify-write: #771 fixed a literal
    # null going on the wire, and "comfort" is the value that has been accepted
    # on real vehicles. The car does not report a mode in its settings, so there
    # is nothing stored to preserve and no evidence that omitting it is safe.
    mode = params.get("climatisation_mode") or settings.get("climatisationMode")
    body["climatisationMode"] = mode or "comfort"

    for name, field in _START_OVERRIDES.items():
        value = params.get(name)
        if value is not None:
            body[field] = bool(value)

    return body


SUCCEEDED = "succeeded"
FAILED = "failed"
REQUEST_SUCCESSFUL = "request_successful"
REQUEST_FAILED = "request_failed"

# Scope requested for the Device Authorization Grant. "mbb" is required for the
# legacy MBB / fs-car endpoints (lock/unlock, trip statistics, climater); the
# other scopes cover account identity and the CARIAD BFF vehicle data.
DEVICE_CODE_SCOPE = "openid mbb profile badge cars dealers vin"

# Auth0 tokens target CARIAD directly and cannot use the legacy IDK endpoint.
_AUTH0_AUTHORIZATION_ENDPOINT = "https://group.identity.vwgroup.io/authorize"
_AUTH0_TOKEN_ENDPOINT = "https://group.identity.vwgroup.io/oauth/token"
_AUTH0_AUDIENCE = "https://api.cariad.com"
_AUTH0_SCOPE = "openid profile offline_access"

_LOGGER = logging.getLogger(__name__)


class AudiAuthError(Exception):
    """Raised when authorization is missing or a token has been rejected."""


class AudiTokenRefreshError(Exception):
    """Raised when a token refresh is rejected for a reason re-authenticating
    cannot fix — e.g. ``invalid_client`` (the client_id is fixed in code, so a
    reauth reuses the same client), or a transient / malformed response. It is
    treated as a retryable update failure rather than escalated to reauth.
    """


# OAuth errors on a refresh exchange that genuinely need the user to sign in
# again: the refresh token itself is rejected, and only a fresh grant can fix
# it. Everything else — invalid_client, a transient blip, a malformed body — is
# retried instead of raising an un-actionable reauth prompt. Listing the hard
# failures (rather than the transient ones) means an unknown code degrades to a
# retry, which is the harmless direction.
_REFRESH_REAUTH_ERRORS = frozenset({"invalid_grant", "invalid assertion headers"})


def _raise_refresh_rejected(context: str, parsed: dict, raw: str) -> NoReturn:
    """Raise for a refresh-token exchange that returned no access token.

    ``invalid_grant`` → AudiAuthError (reauth genuinely needed); anything else →
    AudiTokenRefreshError (retryable, no reauth prompt). Used for both the IDK
    refresh and the mbboauth refresh, so it prefers ``error_description`` (which
    mbboauth returns) for the message while classifying on ``error``.
    """
    detail = str(parsed.get("error_description") or parsed.get("error") or raw[:200])
    if parsed.get("error") in _REFRESH_REAUTH_ERRORS:
        raise AudiAuthError(f"{context}: {detail}")
    raise AudiTokenRefreshError(f"{context}: {detail}")


def _to_absolute(absolute_url: str, relative_url: str) -> str:
    """Convert a relative url to an absolute url."""
    url_parts = urlparse(absolute_url)
    return url_parts.scheme + "://" + url_parts.netloc + relative_url


class AudiService:
    def __init__(
        self, api: AudiAPI, country: str, spin: str | None, api_level: int
    ) -> None:
        self._api = api
        self._country = country
        self._language: str | None = None
        self._type = "Audi"
        self._spin = spin
        self._homeRegion: dict[str, str] = {}
        self._homeRegionSetter = {}
        self.mbbOAuthBaseURL = None
        self.mbboauthToken = None
        self.xclientId = None
        self._tokenEndpoint = ""
        self._authorizationEndpoint = ""
        self._bearer_token_json = None
        self._uses_auth0 = False
        # Scoped to the live session: next polling cycles omit explicitly
        # unsupported CARIAD jobs, without any additional Audi requests.
        self._cariad_capabilities: dict[str, tuple[frozenset[str], frozenset[str]]] = {}
        # Fixed job labels only, never data values. Scoped to this Audi session.
        self._cariad_observed_jobs: dict[str, frozenset[str]] = {}
        self._client_id = ""
        self._authorizationServerBaseURLLive = ""
        self._api_level = api_level

        if self._api_level is None:
            self._api_level = DEFAULT_API_LEVEL

        if self._country is None:
            self._country = "DE"

    def get_hidden_html_input_form_data(
        self, response: str, form_data: dict[str, str]
    ) -> dict[str, str]:
        # Now parse the html body and extract the target url, csrf token and other required parameters
        html = BeautifulSoup(response, "html.parser")
        form_inputs = html.find_all("input", attrs={"type": "hidden"})
        for form_input in form_inputs:
            name = form_input.get("name")
            form_data[name] = form_input.get("value")

        return form_data

    def get_post_url(self, response: str, url: str) -> str:
        # Now parse the html body and extract the target url, csrf token and other required parameters
        html = BeautifulSoup(response, "html.parser")
        form_tag = html.find("form")

        # Extract the target url
        action = form_tag.get("action")
        if action.startswith("http"):
            # Absolute url
            username_post_url = action
        elif action.startswith("/"):
            # Relative to domain
            username_post_url = _to_absolute(url, action)
        else:
            raise ValueError("Unknown form action: " + action)
        return username_post_url

    async def refresh_vehicle_data(self, vin: str):
        request_id = await self.request_current_vehicle_data(vin.upper())
        await self.check_bff_request_succeeded(vin, request_id)

    async def request_current_vehicle_data(self, vin: str):
        self._api.use_token(self._bearer_token_json)
        data = await self._api.post(
            self.__get_cariad_url_for_vin(vin, "vehiclewakeup"),
            data=None,
            use_json=False,
        )

        request_id = data.get("data", {}).get("requestID")
        if request_id is None:
            raise Exception("Vehicle wakeup response did not contain requestID")

        return request_id

    async def get_preheater(self, vin: str):
        self._api.use_token(self.vwToken)
        return await self._api.get(
            f"{await self._get_home_region(vin.upper())}/fs-car/bs/rs/v1/{self._type}/{self._country}/vehicles/{vin.upper()}/status"
        )

    async def probe_known_read_only_paths(
        self, vin: str, *, extended: bool = False
    ) -> dict[str, Any]:
        """Use current CARIAD credentials for opt-in diagnostic GET probes.

        Does not create/refresh an auth session or send an action.
        """
        token = self._bearer_token_json
        access_token = token.get("access_token") if isinstance(token, dict) else None
        if not isinstance(access_token, str) or not access_token:
            raise ValueError("Active CARIAD access token unavailable")
        self._api.use_token(token)
        return await run_read_only_probes(
            self._api,
            access_token,
            lambda suffix: self.__get_cariad_url_for_vin(vin, suffix),
            extended=extended,
        )

    async def get_stored_vehicle_data(self, vin: str):
        """Poll CARIAD with explicit aliases and previously observed valid jobs.

        A 207 or a partial payload may contain useful jobs alongside errors.
        Preserve the evidence and mark incomplete reports for conservative
        state merging; do not add retries or extra network calls.
        """
        key = vin.upper()
        known = self._cariad_capabilities.get(key)
        observed = self._cariad_observed_jobs.get(key, frozenset())
        jobs = (
            select_jobs(*known, observed=observed)
            if known is not None
            else select_jobs()
        )
        self._api.use_token(self._bearer_token_json)
        data = await self._api.get(
            self.__get_cariad_url_for_vin(
                vin, "selectivestatus?jobs={jobs}", jobs=",".join(jobs)
            )
        )
        snapshot = capability_snapshot(data)
        if snapshot is not None:
            self._cariad_capabilities[key] = snapshot
        learned = observed_readable_jobs(data, jobs)
        if learned:
            self._cariad_observed_jobs[key] = observed | learned
        response = VehicleDataResponse(data)
        # Pruned requests and missing job keys are never complete snapshots.
        # A successful HTTP status (including 207) does not change this.
        response.partial_response = (
            len(jobs) != len(BASE_SELECTIVE_JOBS)
            or not isinstance(data, dict)
            or any(job not in data for job in jobs)
        )
        _LOGGER.debug(
            "Vehicle selective-status received (%d jobs; capabilities %s; "
            "partial=%s; payload redacted)",
            len(jobs),
            "known" if snapshot is not None else "unknown",
            response.partial_response,
        )
        return response

    async def get_charger(self, vin: str):
        self._api.use_token(self.vwToken)
        return await self._api.get(
            f"{await self._get_home_region(vin.upper())}/fs-car/bs/batterycharge/v1/{self._type}/{self._country}/vehicles/{vin.upper()}/charger"
        )

    async def get_climater(self, vin: str):
        self._api.use_token(self.vwToken)
        return await self._api.get(
            f"{await self._get_home_region(vin.upper())}/fs-car/bs/climatisation/v1/{self._type}/{self._country}/vehicles/{vin.upper()}/climater"
        )

    async def get_stored_position(self, vin: str):
        self._api.use_token(self._bearer_token_json)
        return await self._api.get(
            self.__get_cariad_url_for_vin(vin, "parkingposition")
        )

    async def get_operations_list(self, vin: str):
        self._api.use_token(self.vwToken)
        return await self._api.get(
            "https://mal-1a.prd.ece.vwg-connect.com/api/rolesrights/operationlist/v3/vehicles/"
            + vin.upper()
        )

    async def get_timer(self, vin: str):
        self._api.use_token(self.vwToken)
        return await self._api.get(
            f"{await self._get_home_region(vin.upper())}/fs-car/bs/departuretimer/v1/{self._type}/{self._country}/vehicles/{vin.upper()}/timer"
        )

    async def get_vehicles(self):
        self._api.use_token(self.vwToken)
        return await self._api.get(
            f"https://msg.volkswagen.de/fs-car/usermanagement/users/v1/{self._type}/{self._country}/vehicles"
        )

    async def get_vehicle_information(self):
        headers = {
            "Accept": "application/json",
            "Accept-Charset": "utf-8",
            "X-App-Name": "myAudi",
            "X-App-Version": AudiAPI.HDR_XAPP_VERSION,
            "Accept-Language": f"{self._language}-{self._country.upper()}",
            "X-User-Country": self._country.upper(),
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Authorization": "Bearer " + self.audiToken["access_token"],
            "Content-Type": "application/json; charset=utf-8",
        }
        req_data = {
            "query": "query vehicleList {\n userVehicles {\n vin\n mappingVin\n vehicle { core { modelYear\n }\n media { shortName\n longName }\n }\n csid\n commissionNumber\n type\n devicePlatform\n mbbConnect\n userRole {\n role\n }\n vehicle {\n classification {\n driveTrain\n }\n }\n nickname\n }\n}"
        }
        req_rsp, rep_rsptxt = await self._api.request(
            "POST",
            "https://app-api.my.aoa.audi.com/vgql/v1/graphql"
            if self._country.upper() == "US"
            else "https://app-api.live-my.audi.com/vgql/v1/graphql",  # Starting in 2023, US users need to point at the aoa (Audi of America) URL.
            json.dumps(req_data),
            headers=headers,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        vins = json.loads(rep_rsptxt)
        if "data" not in vins or vins["data"] is None:
            if "errors" in vins:
                raise Exception(f"API returned errors: {vins['errors']}")
            raise Exception("No data in API response")

        if vins["data"].get("userVehicles") is None:
            if "errors" in vins:
                raise Exception(f"API returned errors: {vins['errors']}")
            raise Exception(
                "No vehicle data in API response - possible authentication issue"
            )

        # GraphQL may return usable vehicle data with enrichment errors.
        if "errors" in vins:
            _LOGGER.debug(
                "Vehicle discovery returned non-fatal enrichment errors: %s",
                [error.get("message") for error in vins["errors"]],
            )

        response = VehiclesResponse()
        response.parse(vins["data"])
        return response

    async def get_vehicle_data(self, vin: str):
        self._api.use_token(self.vwToken)
        return await self._api.get(
            f"{await self._get_home_region(vin.upper())}/fs-car/vehicleMgmt/vehicledata/v2/{self._type}/{self._country}/vehicles/{vin.upper()}/"
        )

    async def get_tripdata(self, vin: str, kind: str):
        self._api.use_token(self.vwToken)

        # read tripdata
        headers = {
            "Accept": "application/json",
            "Accept-Charset": "utf-8",
            "X-App-Name": "myAudi",
            "X-App-Version": AudiAPI.HDR_XAPP_VERSION,
            "X-Client-ID": self.xclientId,
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Authorization": "Bearer " + self.vwToken["access_token"],
        }
        td_reqdata = {
            "type": "list",
            "from": "1970-01-01T00:00:00Z",
            # "from":(datetime.now(timezone.utc) - timedelta(days=365)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "to": (datetime.now(UTC) + timedelta(minutes=90)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"
            ),
        }
        data = await self._api.request(
            "GET",
            f"{await self._get_home_region_setter(vin.upper())}/api/bs/tripstatistics/v1/vehicles/{vin.upper()}/tripdata/{kind}",
            None,
            params=td_reqdata,
            headers=headers,
        )
        td_sorted = sorted(
            data["tripDataList"]["tripData"],
            key=lambda k: k["overallMileage"],
            reverse=True,
        )
        # _LOGGER.debug("get_tripdata: td_sorted: %s", td_sorted)
        td_current = td_sorted[0]
        # FIX, TR/2023-03-25: Assign just in case td_sorted contains only one item
        td_reset_trip = td_sorted[0]

        for trip in td_sorted:
            if (td_current["startMileage"] - trip["startMileage"]) > 2:
                td_reset_trip = trip
                break
            else:
                td_current["tripID"] = trip["tripID"]
                td_current["startMileage"] = trip["startMileage"]
        _LOGGER.debug("TRIP DATA: td_current: %s", td_current)
        _LOGGER.debug("TRIP DATA: td_reset_trip: %s", td_reset_trip)

        return TripDataResponse(td_current), TripDataResponse(td_reset_trip)

    async def _fill_home_region(self, vin: str):
        # the home-region endpoint returns
        # https://ha-5a.prd.eu.vwg.vwautocloud.net which is no valid endpoint
        # (at least not in DE region). set it statically.
        if self._country.upper() != "US" and self._api_level == 1:
            self._homeRegion[vin] = "https://mal-3a.prd.eu.dp.vwg-connect.com"
            self._homeRegionSetter[vin] = "https://mal-3a.prd.eu.dp.vwg-connect.com"
            return
        self._homeRegion[vin] = "https://msg.volkswagen.de"
        self._homeRegionSetter[vin] = "https://mal-1a.prd.ece.vwg-connect.com"

        try:
            self._api.use_token(self.vwToken)
            res = await self._api.get(
                f"https://mal-1a.prd.ece.vwg-connect.com/api/cs/vds/v1/vehicles/{vin}/homeRegion"
            )
            if (
                res is not None
                and res.get("homeRegion") is not None
                and res["homeRegion"].get("baseUri") is not None
                and res["homeRegion"]["baseUri"].get("content") is not None
            ):
                uri = res["homeRegion"]["baseUri"]["content"]
                if UNUSABLE_HOME_REGION_HOST in uri:
                    # The endpoint hands back ha-5a.prd.<region>.vwg.vwautocloud.net,
                    # which does not serve a usable certificate chain and fails with
                    # CERTIFICATE_VERIFY_FAILED. The static default above already
                    # works, so keep it. The guard at the top of this method covers
                    # the same host for non-US accounts on API level 1; this covers
                    # every other combination, which is how US accounts (#829) and
                    # API level 0 accounts in Europe still reached it.
                    _LOGGER.debug(
                        "HOME REGION: ignoring unusable base URI %s, keeping %s",
                        uri,
                        self._homeRegion[vin],
                    )
                elif uri != "https://mal-1a.prd.ece.vwg-connect.com/api":
                    self._homeRegionSetter[vin] = uri.split("/api")[0]
                    self._homeRegion[vin] = self._homeRegionSetter[vin].replace(
                        "mal-", "fal-"
                    )
        except Exception:
            pass

    async def _get_home_region(self, vin: str):
        if self._homeRegion.get(vin) is not None:
            return self._homeRegion[vin]

        await self._fill_home_region(vin)

        return self._homeRegion[vin]

    async def _get_home_region_setter(self, vin: str):
        if self._homeRegionSetter.get(vin) is not None:
            return self._homeRegionSetter[vin]

        await self._fill_home_region(vin)

        return self._homeRegionSetter[vin]

    async def _get_security_token(self, vin: str, action: str):
        # Challenge
        headers = {
            "User-Agent": "okhttp/3.7.0",
            "X-App-Version": "3.14.0",
            "X-App-Name": "myAudi",
            "Accept": "application/json",
            "Authorization": "Bearer " + self.vwToken.get("access_token"),
        }

        body = await self._api.request(
            "GET",
            f"{await self._get_home_region_setter(vin.upper())}/api/rolesrights/authorization/v2/vehicles/"
            + vin.upper()
            + "/services/"
            + action
            + "/security-pin-auth-requested",
            headers=headers,
            data=None,
        )
        secToken = body["securityPinAuthInfo"]["securityToken"]
        challenge = body["securityPinAuthInfo"]["securityPinTransmission"]["challenge"]

        # Response
        securityPinHash = self._generate_security_pin_hash(challenge)
        data = {
            "securityPinAuthentication": {
                "securityPin": {
                    "challenge": challenge,
                    "securityPinHash": securityPinHash,
                },
                "securityToken": secToken,
            }
        }

        headers = {
            "User-Agent": "okhttp/3.7.0",
            "Content-Type": "application/json",
            "X-App-Version": "3.14.0",
            "X-App-Name": "myAudi",
            "Accept": "application/json",
            "Authorization": "Bearer " + self.vwToken.get("access_token"),
        }

        body = await self._api.request(
            "POST",
            f"{await self._get_home_region_setter(vin.upper())}/api/rolesrights/authorization/v2/security-pin-auth-completed",
            headers=headers,
            data=json.dumps(data),
        )
        return body["securityToken"]

    def _get_vehicle_action_header(
        self, content_type: str, security_token: str | None, host: str | None = None
    ) -> dict[str, str]:
        if not host:
            host = (
                "mal-3a.prd.eu.dp.vwg-connect.com"
                if self._country in {"DE", "US"}
                else "msg.volkswagen.de"
            )

        headers = {
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Host": host,
            "X-App-Version": AudiAPI.HDR_XAPP_VERSION,
            "X-App-Name": "myAudi",
            "Authorization": "Bearer " + self.vwToken.get("access_token"),
            "Accept-charset": "UTF-8",
            "Content-Type": content_type,
            "Accept": "application/json, application/vnd.vwg.mbb.ChargerAction_v1_0_0+xml,application/vnd.volkswagenag.com-error-v1+xml,application/vnd.vwg.mbb.genericError_v1_0_2+xml, application/vnd.vwg.mbb.RemoteStandheizung_v2_0_0+xml, application/vnd.vwg.mbb.genericError_v1_0_2+xml,application/vnd.vwg.mbb.RemoteLockUnlock_v1_0_0+xml,*/*",
        }

        if security_token:
            headers["x-securityToken"] = security_token

        return headers

    def __build_url(
        self, base_url: str, path_and_query: str, **path_and_query_kwargs: Any
    ) -> str:
        action_path = path_and_query.format(**path_and_query_kwargs)

        return base_url.rstrip("/") + "/" + action_path.lstrip("/")

    def __get_cariad_url(
        self, path_and_query: str, **path_and_query_kwargs: Any
    ) -> str:
        base_url = "https://{region}.bff.cariad.digital".format(
            region="emea" if self._country.upper() != "US" else "na"
        )

        return self.__build_url(base_url, path_and_query, **path_and_query_kwargs)

    def __get_cariad_url_for_vin(
        self, vin: str, path_and_query: str, **path_and_query_kwargs: Any
    ) -> str:
        base_url = self.__get_cariad_url("/vehicle/v1/vehicles/{vin}", vin=vin.upper())

        return self.__build_url(base_url, path_and_query, **path_and_query_kwargs)

    async def set_vehicle_lock(self, vin: str, lock: bool):
        """Use the CARIAD access API with Auth0, legacy RLU only with legacy auth.

        Audi's 2026 Auth0 sessions no longer authorize the old
        rolesrights/rlu_v1 PIN challenge used by the pre-2026 integration.
        Do not retry a failed access command on another backend: unlocking is a
        security-sensitive mutation and blind retries can have side effects.
        """
        if self._uses_auth0:
            return await self._set_vehicle_lock_cariad(vin, lock)
        return await self._set_vehicle_lock_legacy(vin, lock)

    async def _set_vehicle_lock_cariad(self, vin: str, lock: bool) -> None:
        """Modern /access/lock and /access/unlock route (Audi connector reference).

        The Audi BFF expects the S-PIN as a JSON field, unlike legacy RLU
        challenge/response. Never log the payload, VIN, or authorization data.
        HTTP 200 means *accepted by gateway*, not proven physical door state.
        """
        if not self._spin:
            raise ValueError("An Audi S-PIN is required for remote door control")
        if not self._bearer_token_json or not self._bearer_token_json.get(
            "access_token"
        ):
            raise AudiAuthError("Audi Auth0 access token is unavailable")
        action = "lock" if lock else "unlock"
        headers = {
            "Authorization": "Bearer " + self._bearer_token_json["access_token"],
            "Accept": "application/json",
            "Content-Type": "application/json",
        }
        self._api.use_token(self._bearer_token_json)
        try:
            reply = await self._api.request(
                "POST",
                self.__get_cariad_url_for_vin(vin, f"access/{action}"),
                headers=headers,
                data=json.dumps({"spin": self._spin}),
            )
        except ClientResponseError as err:
            # CARIAD may acknowledge a mutation with 204 No Content.
            # This is only a transport acknowledgement, not a door-state check.
            if err.status != 204:
                raise
            reply = None
        request_id = (
            get_attr(reply, "data.requestID") if isinstance(reply, dict) else None
        )
        if request_id:
            await self._confirm_vehicle_request(
                vin, action, request_id, noun="Door lock"
            )
        else:
            _LOGGER.debug(
                "Door %s request acknowledged without a confirmation id; "
                "verify lock status after the next vehicle refresh",
                action,
            )

    async def _set_vehicle_lock_legacy(self, vin: str, lock: bool) -> None:
        security_token = await self._get_security_token(
            vin, "rlu_v1/operations/" + ("LOCK" if lock else "UNLOCK")
        )
        # deprecated data removed on 24Mar2025
        # data = '<?xml version="1.0" encoding= "UTF-8" ?><rluAction xmlns="http://audi.de/connect/rlu"><action>{action}</action></rluAction>'.format(
        #     action="lock" if lock else "unlock"
        # )
        data = None

        headers = self._get_vehicle_action_header(
            "application/vnd.vwg.mbb.RemoteLockUnlock_v1_0_0+xml", security_token
        )
        res = await self._api.request(
            "POST",
            "{homeRegionSetter}/api/bs/rlu/v1/vehicles/{vin}/{action}".format(
                homeRegionSetter=await self._get_home_region_setter(vin.upper()),
                vin=vin.upper(),
                action="lock" if lock else "unlock",
            ),
            headers=headers,
            data=data,
        )

        checkUrl = "{homeRegionSetter}/api/bs/rlu/v1/vehicles/{vin}/requests/{requestId}/status".format(
            homeRegionSetter=await self._get_home_region_setter(vin.upper()),
            vin=vin.upper(),
            requestId=res["rluActionResponse"]["requestId"],
        )

        await self.check_request_succeeded(
            checkUrl,
            "lock vehicle" if lock else "unlock vehicle",
            REQUEST_SUCCESSFUL,
            REQUEST_FAILED,
            "requestStatusResponse.status",
        )

    async def set_battery_charger(self, vin: str, start: bool, timer: bool):
        """Start or stop charging.

        start=True, timer=True  -> select timer mode, so the car charges on its
                                   own schedule rather than immediately.
        start=True, timer=False -> start charging now.
        start=False             -> stop charging now.

        Until 2.3.1 all three only PUT charging/mode, which sets a *mode
        preference* and neither starts nor stops a charge, and the stop case
        raised outright (upstream #725). charging/start and charging/stop are the
        routes current firmware exposes for the action itself, cross-checked
        against two independent BFF clients.
        """
        if start and timer:
            await self.set_preferred_charge_mode(vin, "timer")
            return

        await self._send_charging_command(vin, "start" if start else "stop")

    async def set_preferred_charge_mode(self, vin: str, mode: str) -> None:
        """Set which mode the car charges in. A preference, not an action: it does
        not start or stop a charge in progress."""
        headers = {"Authorization": "Bearer " + self._bearer_token_json["access_token"]}

        await self._api.request(
            "PUT",
            self.__get_cariad_url_for_vin(vin, "charging/mode"),
            headers=headers,
            data=json.dumps({"preferredChargeMode": mode}),
        )

    async def _post_charging_command(
        self, vin: str, suffix: str, body: dict[str, Any]
    ) -> Any:
        """POST one BFF charging command.

        Returns the parsed body, or None when the car answers 204. The shared
        request helper raises ClientResponseError for every status outside
        200/202/207, 204 included, so a no-content success arrives here as an
        exception and has to be turned back into one.
        """
        headers = {"Authorization": "Bearer " + self._bearer_token_json["access_token"]}
        try:
            return await self._api.request(
                "POST",
                self.__get_cariad_url_for_vin(vin, suffix),
                headers=headers,
                data=json.dumps(body),
            )
        except ClientResponseError as err:
            if err.status == 204:
                return None
            raise

    async def _send_charging_command(self, vin: str, action: str) -> None:
        """Actually start or stop a charge.

        Separate charging/start and charging/stop are what current firmware
        exposes; the combined charging/start-stop route is kept as a 404 fallback
        for older cars. Both shapes are used by CarConnectivity-connector-volkswagen
        and vwgroup-connect-ha against the same CARIAD BFF.
        """
        try:
            res = await self._post_charging_command(vin, f"charging/{action}", {})
        except ClientResponseError as err:
            if err.status != 404:
                raise
            _LOGGER.debug(
                "charging/%s not provisioned for %s, trying the combined route",
                action,
                vin,
            )
            res = await self._post_charging_command(
                vin, "charging/start-stop", {"action": action}
            )

        request_id = get_attr(res, "data.requestID") if isinstance(res, dict) else None
        if request_id is None:
            _LOGGER.debug(
                "Charging %s accepted for %s with no request id to confirm against",
                action,
                vin,
            )
            return

        await self._confirm_charging_command(vin, action, request_id)

    async def _confirm_charging_command(
        self, vin: str, action: str, request_id: str
    ) -> None:
        """Confirm a charging command. Thin wrapper kept for its call sites."""
        await self._confirm_vehicle_request(
            vin,
            action,
            request_id,
            noun="Charging",
            attempts=CHARGING_CONFIRM_ATTEMPTS,
            sleep=CHARGING_CONFIRM_SLEEP,
        )

    async def _confirm_vehicle_request(
        self,
        vin: str,
        action: str,
        request_id: str,
        noun: str = "Charging",
        attempts: int = CHARGING_CONFIRM_ATTEMPTS,
        sleep: int = CHARGING_CONFIRM_SLEEP,
    ) -> None:
        """Poll pendingrequests until the car acts on the command.

        Deliberately shorter than check_bff_request_succeeded (10 polls, 10s
        apart): every poll is an API call against a metered daily allowance, and
        this runs inside a service call the user is waiting on. Running out of
        attempts is reported as unconfirmed rather than failed, so a command that
        did work is never announced as broken. An explicit rejection still
        raises.
        """
        headers = {
            "Accept": "application/json",
            "Authorization": "Bearer " + self._bearer_token_json["access_token"],
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/json; charset=utf-8",
        }

        for _ in range(attempts):
            await asyncio.sleep(sleep)
            try:
                res = await self._api.request(
                    "GET",
                    self.__get_cariad_url_for_vin(vin, "pendingrequests"),
                    headers=headers,
                    data=None,
                )
            except ClientResponseError as err:
                if err.status != 204:
                    raise
                res = None

            entries = get_attr(res, "data") or []
            if not isinstance(entries, list):
                entries = []
            for pending_request in entries:
                if not isinstance(pending_request, dict):
                    continue
                if pending_request.get("id") != request_id:
                    continue
                status = pending_request.get("status")
                if status == "in_progress":
                    break
                if status == "successful":
                    _LOGGER.debug("%s %s confirmed by CARIAD", noun, action)
                    return
                raise RuntimeError(
                    f"{noun} {action} rejected by the vehicle "
                    f"(confirmation state {str(status)[:32]})"
                )

        _LOGGER.warning(
            "%s %s was accepted but not confirmed within %ds. "
            "The command may still be carried out; verify vehicle state.",
            noun,
            action,
            attempts * sleep,
        )

        # checkUrl = "{homeRegion}/fs-car/bs/batterycharge/v1/{type}/{country}/vehicles/{vin}/charger/actions/{actionid}".format(
        #     homeRegion=await self._get_home_region(vin.upper()),
        #     type=self._type,
        #     country=self._country,
        #     vin=vin.upper(),
        #     actionid=res["action"]["actionId"],
        # )

        # await self.check_request_succeeded(
        #     checkUrl,
        #     "start charger" if start else "stop charger",
        #     SUCCEEDED,
        #     FAILED,
        #     "action.actionState",
        # )

    async def get_charging_profiles_raw(self, vin: str) -> dict:
        """Fetch just the chargingProfiles job, unparsed.

        The write is a read-modify-write and the BFF replaces the whole profile,
        so we need the profile exactly as the car reports it, not the scrubbed
        summary the sensor keeps.
        """
        self._api.use_token(self._bearer_token_json)
        return await self._api.get(
            self.__get_cariad_url_for_vin(
                vin, "selectivestatus?jobs={jobs}", jobs="chargingProfiles"
            )
        )

    async def set_location_charge_target(
        self, vin: str, profile_id: int | None, target_soc: int
    ) -> None:
        """Set a location charging profile's target SoC.

        This is the value that actually governs where a charge stops at a
        location; the global charging/settings target does not (upstream #722).

        Endpoint, verb and body shape are from the myAudi app 4.30:
            PUT charging/profiles   body {"profile": {<whole profile>}}
        The PUT replaces the entire profile, so this reads the current one,
        changes only targetSOC_pct, and sends everything else back unchanged.
        Never invent or drop a field.

        profile_id None targets the profile the car is currently parked in.
        """
        raw = await self.get_charging_profiles_raw(vin)
        value = get_attr(raw, "chargingProfiles.chargingProfilesStatus.value")
        profile_id, put_body = build_profile_update(value, profile_id, target_soc)

        headers = {
            "Authorization": "Bearer " + self._bearer_token_json["access_token"],
            "Content-Type": "application/json",
        }
        try:
            res = await self._api.request(
                "PUT",
                self.__get_cariad_url_for_vin(vin, "charging/profiles"),
                headers=headers,
                data=json.dumps(put_body),
            )
        except ClientResponseError as err:
            if err.status == 204:
                res = None
            else:
                raise

        request_id = get_attr(res, "data.requestID") if isinstance(res, dict) else None
        if request_id is None:
            _LOGGER.debug(
                "Location charge target for %s accepted with no request id to confirm",
                vin,
            )
            return
        await self._confirm_charging_command(
            vin, f"profile {profile_id} target {target_soc}%", request_id
        )

    async def flash_lights(
        self, vin: str, latitude: float, longitude: float, duration_s: int = 10
    ) -> None:
        """Flash the vehicle's lights.

        Endpoint and body shape are from WeConnect-python, which drives the same
        Cariad BFF:

            POST {bff}/vehicle/v1/vehicles/{vin}/honkandflash
            {"duration_s": 10, "mode": "flash",
             "userPosition": {"latitude": .., "longitude": ..}}

        The position is required, which is why a GET against this path returns
        404 rather than 405: there is no GET route at all.

        The mode is hard-coded. The same endpoint sounds the horn when given
        "honkandflash", and there is deliberately no parameter through which a
        caller could reach that: a control that can wake a street by passing the
        wrong string is not worth the flexibility.
        """
        headers = {"Authorization": "Bearer " + self._bearer_token_json["access_token"]}
        data = {
            "duration_s": duration_s,
            "mode": "flash",
            "userPosition": {"latitude": latitude, "longitude": longitude},
        }
        await self._api.request(
            "POST",
            self.__get_cariad_url_for_vin(vin, "honkandflash"),
            headers=headers,
            data=json.dumps(data),
        )

    async def set_climatisation_settings(self, vin: str, **changes: Any) -> None:
        """Change climatisation settings without starting climatisation.

        PUT {bff}/vehicle/v1/vehicles/{vin}/climatisation/settings

        Endpoint and field names are from WeConnect-python, which drives the
        same Cariad BFF. An earlier GET against this path returned 404, which
        was read as the endpoint not existing; it means there is no GET route.
        The honk-and-flash work later demonstrated the same 404-on-GET on this
        API for a path that is perfectly real for its own verb.
        """
        current = await self.get_climatisation_settings_raw(vin)
        body = build_climatisation_settings_update(current, **changes)

        headers = {"Authorization": "Bearer " + self._bearer_token_json["access_token"]}
        await self._api.request(
            "PUT",
            self.__get_cariad_url_for_vin(vin, "climatisation/settings"),
            headers=headers,
            data=json.dumps(body),
        )

    async def get_charging_settings_raw(self, vin: str) -> dict[str, Any]:
        """Read actual car charging settings before an Auth0 settings mutation.

        CARIAD charging/settings can replace several settings. Never overwrite
        unknown car preferences with a partial request or guessed defaults.
        """
        self._api.use_token(self._bearer_token_json)
        response = await self._api.get(
            self.__get_cariad_url_for_vin(
                vin, "selectivestatus?jobs={jobs}", jobs="charging"
            )
        )
        settings = (response or {}).get("charging", {}).get("chargingSettings", {})
        value = settings.get("value") if isinstance(settings, dict) else None
        if not isinstance(value, dict) or not value:
            raise ValueError(
                "Audi has not returned charging settings; refusing blind update"
            )
        return value

    async def set_target_state_of_charge(self, vin: str, target_soc: int):
        """Set the target state of charge (battery percentage)."""
        if not (20 <= target_soc <= 100):
            raise ValueError(
                "Target state of charge must be between 20 and 100 percent"
            )

        # Use Cariad BFF API (requires API level 1)
        headers = {"Authorization": "Bearer " + self._bearer_token_json["access_token"]}

        data = {"targetSOC_pct": target_soc}
        if self._uses_auth0:
            current = await self.get_charging_settings_raw(vin)
            # A CARIAD PUT may replace the complete object. Unknown vehicle
            # settings must not be silently dropped or replayed blindly.
            writable = frozenset(
                (
                    "maxChargeCurrentAC_A",
                    "maxChargeCurrentAC",
                    "autoUnlockPlugWhenChargedAC",
                    "targetSOC_pct",
                )
            )
            metadata = frozenset({"carCapturedTimestamp"})
            if set(current) - writable - metadata:
                raise ValueError(
                    "Audi reported unrecognized charging settings; refusing "
                    "a potentially destructive full-replacement PUT"
                )
            data = {
                key: current[key]
                for key in writable
                if key in current and current[key] is not None
            }
            data["targetSOC_pct"] = target_soc

        await self._api.request(
            "PUT",
            self.__get_cariad_url_for_vin(vin, "charging/settings"),
            headers=headers,
            data=json.dumps(data),
        )

    async def get_climatisation_settings_raw(self, vin: str) -> dict:
        """Fetch just the climatisation job, unparsed.

        The start endpoint replaces the whole settings object, so it needs the
        fields exactly as the car reports them rather than a parsed subset.
        """
        self._api.use_token(self._bearer_token_json)
        data = await self._api.get(
            self.__get_cariad_url_for_vin(
                vin, "selectivestatus?jobs={jobs}", jobs="climatisation"
            )
        )
        value = (
            (data or {})
            .get("climatisation", {})
            .get("climatisationSettings", {})
            .get("value")
        )
        return value if isinstance(value, dict) else {}

    def _climate_api_level(self) -> int:
        """Auth0 tokens cannot authorize legacy fs-car climatisation actions.

        Route Auth0 sessions to the existing CARIAD command implementation even
        if the entry still holds the historical API Level 0 configuration.
        Do not change other endpoints or the saved user preference.
        """
        if self._uses_auth0:
            return 1
        return self._api_level

    async def set_climatisation(self, vin: str, start: bool):
        api_level = self._climate_api_level()
        country = self._country

        if start:
            raise NotImplementedError(
                "The 'Start Climatisation (Legacy)' service is deprecated and no longer functional. "
                "Please use the 'Start Climate Control' service instead."
            )
            # data = '{"action":{"type": "startClimatisation","settings": {"targetTemperature": 2940,"climatisationWithoutHVpower": true,"heaterSource": "electric","climaterElementSettings": {"isClimatisationAtUnlock": false, "isMirrorHeatingEnabled": true,}}}}'
        else:
            if api_level == 0:
                data = '{"action":{"type": "stopClimatisation"}}'

                if country == "US":
                    headers = self._get_vehicle_action_header("application/json", None)
                    res = await self._api.request(
                        "POST",
                        f"https://mal-3a.prd.eu.dp.vwg-connect.com/api/bs/climatisation/v1/vehicles/{vin.upper()}/climater/actions",
                        headers=headers,
                        data=data,
                    )
                    checkUrl = "https://mal-3a.prd.eu.dp.vwg-connect.com/api/bs/climatisation/v1/vehicles/{vin}/climater/actions/{actionid}".format(
                        vin=vin.upper(),
                        actionid=res["action"]["actionId"],
                    )

                else:
                    headers = self._get_vehicle_action_header(
                        "application/json", None, "msg.volkswagen.de"
                    )
                    res = await self._api.request(
                        "POST",
                        f"{await self._get_home_region(vin.upper())}/fs-car/bs/climatisation/v1/{self._type}/{self._country}/vehicles/{vin.upper()}/climater/actions",
                        headers=headers,
                        data=data,
                    )

                    checkUrl = "{homeRegion}/fs-car/bs/climatisation/v1/{type}/{country}/vehicles/{vin}/climater/actions/{actionid}".format(
                        homeRegion=await self._get_home_region(vin.upper()),
                        type=self._type,
                        country=self._country,
                        vin=vin.upper(),
                        actionid=res["action"]["actionId"],
                    )

                await self.check_request_succeeded(
                    checkUrl,
                    "stop climatisation",
                    SUCCEEDED,
                    FAILED,
                    "action.actionState",
                )

            elif api_level == 1:
                data = None
                headers = {
                    "Authorization": "Bearer " + self._bearer_token_json["access_token"]
                }
                try:
                    res = await self._api.request(
                        "POST",
                        self.__get_cariad_url_for_vin(vin, "climatisation/stop"),
                        headers=headers,
                        data=data,
                    )
                except ClientResponseError as err:
                    if err.status != 204:
                        raise
                    res = None
                request_id = get_attr(res, "data.requestID")
                if request_id:
                    await self._confirm_vehicle_request(
                        vin,
                        "stop",
                        request_id,
                        noun="Climatisation",
                        attempts=CLIMATISATION_CONFIRM_ATTEMPTS,
                        sleep=CLIMATISATION_CONFIRM_SLEEP,
                    )

                # checkUrl = "https://emea.bff.cariad.digital/vehicle/v1/vehicles/{vin}/pendingrequests".format(
                #     vin=vin.upper(),
                #     actionid=res["action"]["actionId"],
                # )

                # await self.check_request_succeeded(
                #     checkUrl,
                #     "startClimatisation",
                #     SUCCEEDED,
                #     FAILED,
                #     "action.actionState",
                # )

    async def start_climate_control(
        self,
        vin: str,
        temp_f: int | None = None,
        temp_c: int | None = None,
        glass_heating: bool | None = None,
        seat_fl: bool | None = None,
        seat_fr: bool | None = None,
        seat_rl: bool | None = None,
        seat_rr: bool | None = None,
        climatisation_at_unlock: bool | None = None,
        climatisation_mode: str | None = None,
    ):
        api_level = self._climate_api_level()
        country = self._country
        target_temperature = None

        _LOGGER.debug(
            "Attempting to start climate control with API Level %s and country %s.",
            api_level,
            country,
        )

        if api_level == 0:
            target_temperature = None
            if temp_f is not None:
                target_temperature = int(((temp_f - 32) * (5 / 9)) * 10 + 2731)
            elif temp_c is not None:
                target_temperature = int(temp_c * 10 + 2731)

            # Default Temp
            target_temperature = target_temperature or 2941

            # Construct Zone Settings
            zone_settings = [
                {"value": {"isEnabled": bool(seat_fl), "position": "frontLeft"}},
                {"value": {"isEnabled": bool(seat_fr), "position": "frontRight"}},
                {"value": {"isEnabled": bool(seat_rl), "position": "rearLeft"}},
                {"value": {"isEnabled": bool(seat_rr), "position": "rearRight"}},
            ]

            data = {
                "action": {
                    "type": "startClimatisation",
                    "settings": {
                        "targetTemperature": target_temperature,
                        "climatisationWithoutHVpower": True,
                        "heaterSource": "electric",
                        "climaterElementSettings": {
                            # bool()-wrapped like the zone settings below: this
                            # endpoint expects a JSON boolean here, never null.
                            # The raw (Optional[bool]) parameter serialises as
                            # `null` when the caller supplies only a temperature
                            # (the climate entity's bare turn_on, #849), and the
                            # legacy fs-car backend rejects that payload with
                            # HTTP 400 before it is queued as a trackable action.
                            "isClimatisationAtUnlock": bool(climatisation_at_unlock),
                            "isMirrorHeatingEnabled": bool(glass_heating),
                            "zoneSettings": {"zoneSetting": zone_settings},
                        },
                    },
                }
            }

            data = json.dumps(data)

            if country == "US":
                headers = self._get_vehicle_action_header("application/json", None)
                res = await self._api.request(
                    "POST",
                    f"https://mal-3a.prd.eu.dp.vwg-connect.com/api/bs/climatisation/v1/vehicles/{vin.upper()}/climater/actions",
                    headers=headers,
                    data=data,
                )

                checkUrl = "https://mal-3a.prd.eu.dp.vwg-connect.com/api/bs/climatisation/v1/vehicles/{vin}/climater/actions/{actionid}".format(
                    vin=vin.upper(),
                    actionid=res["action"]["actionId"],
                )
            else:
                headers = self._get_vehicle_action_header(
                    "application/json", None, "msg.volkswagen.de"
                )
                res = await self._api.request(
                    "POST",
                    f"{await self._get_home_region(vin.upper())}/fs-car/bs/climatisation/v1/{self._type}/{self._country}/vehicles/{vin.upper()}/climater/actions",
                    headers=headers,
                    data=data,
                )

                checkUrl = "{homeRegion}/fs-car/bs/climatisation/v1/{type}/{country}/vehicles/{vin}/climater/actions/{actionid}".format(
                    homeRegion=await self._get_home_region(vin.upper()),
                    type=self._type,
                    country=self._country,
                    vin=vin.upper(),
                    actionid=res["action"]["actionId"],
                )

            await self.check_request_succeeded(
                checkUrl,
                "startClimatisation",
                SUCCEEDED,
                FAILED,
                "action.actionState",
            )

        elif api_level == 1:
            # Some vehicles (for example the Q6 e-tron) reject a settings payload
            # outright, because they have no comfort climatisation profile to apply
            # it to. The vehicle reports the request as failed only after it has
            # synchronised, so the failure shows up in the myAudi app rather than
            # in our HTTP response. When the caller supplied no settings at all,
            # send no body and let the vehicle use the settings stored in the car,
            # which is what the myAudi app does in that case.
            has_settings = any(
                value is not None
                for value in (
                    temp_f,
                    temp_c,
                    climatisation_mode,
                    climatisation_at_unlock,
                    glass_heating,
                    seat_fl,
                    seat_fr,
                    seat_rl,
                    seat_rr,
                )
            )

            data = None
            if has_settings:
                # Read-modify-write: the endpoint replaces the settings object,
                # so anything not sent is cleared. Build from what the car
                # currently holds and change only what the caller asked for.
                stored = await self.get_climatisation_settings_raw(vin)
                if not stored:
                    _LOGGER.debug(
                        "Vehicle reports no climatisation settings; building the start body from defaults."
                    )
                data = json.dumps(
                    build_climatisation_start_body(
                        stored,
                        temp_f=temp_f,
                        temp_c=temp_c,
                        climatisation_mode=climatisation_mode,
                        climatisation_at_unlock=climatisation_at_unlock,
                        glass_heating=glass_heating,
                        seat_fl=seat_fl,
                        seat_fr=seat_fr,
                        seat_rl=seat_rl,
                        seat_rr=seat_rr,
                    )
                )
            else:
                _LOGGER.debug(
                    "No climate settings supplied; starting climatisation with the settings stored in the vehicle."
                )

            headers = {
                "Authorization": "Bearer " + self._bearer_token_json["access_token"]
            }
            try:
                res = await self._api.request(
                    "POST",
                    self.__get_cariad_url_for_vin(vin, "climatisation/start"),
                    headers=headers,
                    data=data,
                )
            except ClientResponseError as err:
                # No-content is a valid acknowledgement for certain BFF
                # actions. Never mistake it for a verified vehicle transition.
                if err.status != 204:
                    raise
                res = None

            # The 200 is the gateway accepting the request, not the car acting on
            # it. Measured on a live vehicle 2026-09-13: a start the car ignored
            # returned 200 with a requestID and only reported "timeout" in
            # pendingrequests about a minute later, so without this a command that
            # never ran was announced as success. Same class as #847's rejected
            # switch command.
            request_id = get_attr(res, "data.requestID")
            if request_id is not None:
                await self._confirm_vehicle_request(
                    vin,
                    "start",
                    request_id,
                    noun="Climatisation",
                    attempts=CLIMATISATION_CONFIRM_ATTEMPTS,
                    sleep=CLIMATISATION_CONFIRM_SLEEP,
                )
            else:
                _LOGGER.debug(
                    "Climatisation start accepted for %s with no request id to confirm",
                    vin,
                )

            # checkUrl = "https://emea.bff.cariad.digital/vehicle/v1/vehicles/{vin}/pendingrequests".format(
            #     vin=vin.upper(),
            #     actionid=res["action"]["actionId"],
            # )

            # await self.check_request_succeeded(
            #     checkUrl,
            #     "startClimatisation",
            #     SUCCEEDED,
            #     FAILED,
            #     "action.actionState",
            # )

    async def trigger_vehicle_wakeup(self, vin: str) -> None:
        """Explicit modern CARIAD vehicle wake-up; never called by polling.

        Based on CarConnectivity-connector-audi's wake command. The API can
        acknowledge a request without the car actually waking. Use only on a
        direct user action, respecting Audi's request limits.
        """
        if not self._uses_auth0:
            raise AudiAuthError("Modern CARIAD wake-up requires Auth0")
        headers = {
            "Authorization": "Bearer " + self._bearer_token_json["access_token"],
            "Content-Type": "application/json",
        }
        try:
            await self._api.request(
                "POST",
                self.__get_cariad_url_for_vin(vin, "vehiclewakeuptrigger"),
                headers=headers,
                data="{}",
            )
        except ClientResponseError as err:
            if err.status != 204:
                raise

    async def set_window_heating(self, vin: str, start: bool):
        if self._uses_auth0:
            # The legacy fs-car XML endpoint cannot be authorized by Auth0.
            # Do not accidentally reroute proven climate START/STOP here.
            headers = {
                "Authorization": "Bearer " + self._bearer_token_json["access_token"],
                "Content-Type": "application/json",
            }
            suffix = "windowheating/start" if start else "windowheating/stop"
            try:
                await self._api.request(
                    "POST",
                    self.__get_cariad_url_for_vin(vin, suffix),
                    headers=headers,
                    data="{}",
                )
            except ClientResponseError as err:
                if err.status != 204:
                    raise
            return
        data = '<?xml version="1.0" encoding= "UTF-8" ?><action><type>{action}</type></action>'.format(
            action="startWindowHeating" if start else "stopWindowHeating"
        )

        headers = self._get_vehicle_action_header(
            "application/vnd.vwg.mbb.ClimaterAction_v1_0_0+xml", None
        )
        res = await self._api.request(
            "POST",
            f"{await self._get_home_region(vin.upper())}/fs-car/bs/climatisation/v1/{self._type}/{self._country}/vehicles/{vin.upper()}/climater/actions",
            headers=headers,
            data=data,
        )

        checkUrl = "{homeRegion}/fs-car/bs/climatisation/v1/{type}/{country}/vehicles/{vin}/climater/actions/{actionid}".format(
            homeRegion=await self._get_home_region(vin.upper()),
            type=self._type,
            country=self._country,
            vin=vin.upper(),
            actionid=res["action"]["actionId"],
        )

        await self.check_request_succeeded(
            checkUrl,
            "start window heating" if start else "stop window heating",
            SUCCEEDED,
            FAILED,
            "action.actionState",
        )

    async def set_pre_heater(
        self, vin: str, activate: bool, duration: int | None = None
    ) -> None:
        if activate:
            if not duration:
                duration = 30
            data = {
                "duration_min": int(duration),
                "spin": self._spin,
            }

            data = json.dumps(data)
        else:
            data = None

        headers = {
            "Accept": "application/json",
            "Accept-charset": "utf-8",
            "Authorization": "Bearer " + self._bearer_token_json["access_token"],
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/json; charset=utf-8",
            "Accept-encoding": "gzip",
        }
        res = await self._api.request(
            "POST",
            self.__get_cariad_url_for_vin(
                vin, "auxiliaryheating/{action}", action="start" if activate else "stop"
            ),
            headers=headers,
            data=data,
        )

        await self.check_bff_request_succeeded(vin, res["data"]["requestID"])

    async def start_engine(self, vin: str) -> None:
        if self._spin is None:
            raise Exception("S-PIN is required to start the engine")

        headers = {
            "Accept": "application/json",
            "Accept-charset": "utf-8",
            "Authorization": "Bearer " + self._bearer_token_json["access_token"],
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/json; charset=utf-8",
            "Accept-encoding": "gzip",
        }

        # Step 1: Obtain userPromptProof
        proof_res = await self._api.request(
            "PUT",
            self.__get_cariad_url(
                "/vehicle/v1/engine/{vin}/userpromptproof", vin=vin.upper()
            ),
            headers=headers,
            data=json.dumps({"spin": self._spin}),
        )
        user_prompt_proof = proof_res["userPromptProof"]

        # Step 2: Submit start request
        res = await self._api.request(
            "POST",
            self.__get_cariad_url("/vehicle/v1/engine/{vin}/start", vin=vin.upper()),
            headers=headers,
            data=json.dumps(
                {
                    "securedActivationData": user_prompt_proof,
                    "spin": self._spin,
                }
            ),
        )

        await self.check_bff_request_succeeded(vin, res["data"]["requestID"])

    async def stop_engine(self, vin: str) -> None:
        headers = {
            "Accept": "application/json",
            "Accept-charset": "utf-8",
            "Authorization": "Bearer " + self._bearer_token_json["access_token"],
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/json; charset=utf-8",
            "Accept-encoding": "gzip",
        }

        res = await self._api.request(
            "POST",
            self.__get_cariad_url("/vehicle/v1/engine/{vin}/stop", vin=vin.upper()),
            headers=headers,
            data=None,
        )

        await self.check_bff_request_succeeded(vin, res["data"]["requestID"])

    async def check_bff_request_succeeded(self, vin: str, request_id: str):
        headers = {
            "Accept": "application/json",
            "Accept-charset": "utf-8",
            "Authorization": "Bearer " + self._bearer_token_json["access_token"],
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/json; charset=utf-8",
            "Accept-encoding": "gzip",
        }

        for _ in range(MAX_RESPONSE_ATTEMPTS):
            await asyncio.sleep(REQUEST_STATUS_SLEEP)
            res = await self._api.request(
                "GET",
                "https://{homeRegion}.bff.cariad.digital/vehicle/v1/vehicles/{vin}/pendingrequests".format(
                    homeRegion="na" if self._country.upper() == "US" else "emea",
                    vin=vin.upper(),
                ),
                headers=headers,
                data=None,
            )

            for pending_request in res["data"]:
                if pending_request["id"] == request_id:
                    if pending_request["status"] == "in_progress":
                        break  # continue waiting

                    if pending_request["status"] == "successful":
                        return

                    raise Exception(
                        "Request {} reached unexpected status {}".format(
                            request_id, pending_request["status"]
                        )
                    )

        raise Exception(f"Request {request_id} timed out")

    async def check_request_succeeded(
        self, url: str, action: str, successCode: str, failedCode: str, path: str
    ):
        for _ in range(MAX_RESPONSE_ATTEMPTS):
            await asyncio.sleep(REQUEST_STATUS_SLEEP)

            self._api.use_token(self.vwToken)
            res = await self._api.get(url)

            status = get_attr(res, path)

            if status is None or (failedCode is not None and status == failedCode):
                raise Exception(f"Cannot {action}, return code '{status}'")

            if status == successCode:
                return

        raise Exception(f"Cannot {action}, operation timed out")

    # TR/2022-12-20: New secret for X_QMAuth
    def _calculate_X_QMAuth(self) -> str:
        # Calculate X-QMAuth value
        gmtime_100sec = int(
            (datetime.now(UTC) - datetime(1970, 1, 1, tzinfo=UTC)).total_seconds() / 100
        )
        xqmauth_secret = bytes(
            [
                26,
                256 - 74,
                256 - 103,
                37,
                256 - 84,
                23,
                256 - 102,
                256 - 86,
                78,
                256 - 125,
                256 - 85,
                256 - 26,
                113,
                256 - 87,
                71,
                109,
                23,
                100,
                24,
                256 - 72,
                91,
                256 - 41,
                6,
                256 - 15,
                67,
                108,
                256 - 95,
                91,
                256 - 26,
                71,
                256 - 104,
                256 - 100,
            ]
        )
        xqmauth_val = hmac.new(
            xqmauth_secret,
            str(gmtime_100sec).encode("ascii", "ignore"),
            digestmod="sha256",
        ).hexdigest()

        # v1:01da27b0:fbdb6e4ba3109bc68040cb83f380796f4d3bb178a626c4cc7e166815b806e4b5
        return "v1:01da27b0:" + xqmauth_val

    async def _request_auth0_token(
        self, data: dict[str, str], context: str
    ) -> dict[str, Any]:
        headers = {
            "Accept": "application/json",
            "Accept-Charset": "utf-8",
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/x-www-form-urlencoded",
        }
        encoded = urlencode(data, encoding="utf-8").replace("+", "%20")
        _rsp, rsptxt = await self._api.request(
            "POST",
            _AUTH0_TOKEN_ENDPOINT,
            encoded,
            headers=headers,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        result = json.loads(rsptxt)
        if "access_token" not in result:
            _raise_refresh_rejected(context, result, rsptxt)
        return result

    def _set_auth0_session(self, result: dict[str, Any]) -> None:
        self._uses_auth0 = True
        self._bearer_token_json = result
        self.audiToken = result
        self.vwToken = result
        self.mbboauthToken = None
        self.xclientId = None
        self._api.set_xclient_id(None)

    async def get_auth0_authorization_url(self, code_challenge: str, state: str) -> str:
        """Return the interactive myAudi Auth0 authorization URL."""
        await self._discover_endpoints()
        params = {
            "client_id": self._client_id,
            "audience": _AUTH0_AUDIENCE,
            "redirect_uri": AUTH0_REDIRECT_URI,
            "response_type": "code",
            "scope": _AUTH0_SCOPE,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "state": state,
            "ui_locales": f"{self._language}-{self._country.upper()}",
        }
        return f"{_AUTH0_AUTHORIZATION_ENDPOINT}?{urlencode(params)}"

    async def login_with_auth0_code(self, code: str, code_verifier: str) -> str:
        """Exchange an interactive Auth0 authorization code."""
        if not self._client_id:
            await self._discover_endpoints()
        result = await self._request_auth0_token(
            {
                "client_id": self._client_id,
                "grant_type": "authorization_code",
                "code": code,
                "code_verifier": code_verifier,
                "redirect_uri": AUTH0_REDIRECT_URI,
            },
            "Auth0 code exchange rejected",
        )
        if "refresh_token" not in result:
            raise AudiAuthError("Auth0 did not issue a refresh token")
        self._set_auth0_session(result)
        return AUTH0_REFRESH_TOKEN_PREFIX + result["refresh_token"]

    async def _refresh_auth0_token(self, refresh_token: str) -> dict[str, Any]:
        """Refresh a token issued by the myAudi Auth0 public client."""
        result = await self._request_auth0_token(
            {
                "client_id": self._client_id,
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "audience": _AUTH0_AUDIENCE,
                "scope": _AUTH0_SCOPE,
            },
            "Auth0 refresh rejected",
        )
        result.setdefault("refresh_token", refresh_token)
        self._set_auth0_session(result)
        return result

    # TR/2021-12-01: Refresh token before it expires
    # returns True when refresh was required and successful, otherwise False
    async def refresh_token_if_necessary(self, elapsed_sec: int) -> bool:
        # The IDK bearer token drives the CARIAD BFF session and carries its own
        # refresh token, independent of the mbboauth token. Base the timing on it
        # and always refresh it: a login whose mbboauth response carried no
        # refresh_token (see _finalize_session) must still keep the IDK session —
        # and therefore every entity — alive past the ~1h access-token lifetime.
        if self._bearer_token_json is None:
            return False
        if "refresh_token" not in self._bearer_token_json:
            return False
        if "expires_in" not in self._bearer_token_json:
            return False

        if (elapsed_sec + 5 * 60) < self._bearer_token_json["expires_in"]:
            # refresh not needed now
            return False

        try:
            if self._uses_auth0:
                await self._refresh_auth0_token(
                    self._bearer_token_json["refresh_token"]
                )
                return True

            # mbboauth refresh — only when a refresh_token is available. The auth
            # response no longer always includes one; when it doesn't, vwToken
            # keeps its current value instead of blocking the IDK refresh below.
            if self.mbboauthToken and "refresh_token" in self.mbboauthToken:
                headers = {
                    "Accept": "application/json",
                    "Accept-Charset": "utf-8",
                    "User-Agent": AudiAPI.HDR_USER_AGENT,
                    "Content-Type": "application/x-www-form-urlencoded",
                    "X-Client-ID": self.xclientId,
                }
                mbboauth_refresh_data = {
                    "grant_type": "refresh_token",
                    "token": self.mbboauthToken["refresh_token"],
                    "scope": "sc2:fal",
                }
                encoded_mbboauth_refresh_data = urlencode(
                    mbboauth_refresh_data, encoding="utf-8"
                ).replace("+", "%20")
                mbboauth_refresh_rsp, mbboauth_refresh_rsptxt = await self._api.request(
                    "POST",
                    self.mbbOAuthBaseURL + "/mobile/oauth2/v1/token",
                    encoded_mbboauth_refresh_data,
                    headers=headers,
                    allow_redirects=False,
                    rsp_wtxt=True,
                )
                # this code is the old "vwToken"
                refreshed = json.loads(mbboauth_refresh_rsptxt)
                if "access_token" not in refreshed:
                    _raise_refresh_rejected(
                        "mbboauth refresh rejected",
                        refreshed,
                        mbboauth_refresh_rsptxt,
                    )
                self.vwToken = refreshed
                # If a new refresh_token is provided, save it for further refreshes
                if "refresh_token" in self.vwToken:
                    self.mbboauthToken["refresh_token"] = self.vwToken["refresh_token"]

            # IDK refresh — always, using the IDK token's own refresh token.
            headers = {
                "Accept": "application/json",
                "Accept-Charset": "utf-8",
                "User-Agent": AudiAPI.HDR_USER_AGENT,
                "Content-Type": "application/x-www-form-urlencoded",
            }
            # IDK token request data
            tokenreq_data = {
                "client_id": self._client_id,
                "grant_type": "refresh_token",
                "refresh_token": self._bearer_token_json.get("refresh_token"),
                "response_type": "token id_token",
            }
            # IDK token request
            encoded_tokenreq_data = urlencode(tokenreq_data, encoding="utf-8").replace(
                "+", "%20"
            )
            bearer_token_rsp, bearer_token_rsptxt = await self._api.request(
                "POST",
                self._tokenEndpoint,
                encoded_tokenreq_data,
                headers=headers,
                allow_redirects=False,
                rsp_wtxt=True,
            )
            refreshed = json.loads(bearer_token_rsptxt)
            if "access_token" not in refreshed:
                _raise_refresh_rejected(
                    "IDK refresh rejected", refreshed, bearer_token_rsptxt
                )
            self._bearer_token_json = refreshed

            # AZS token
            headers = {
                "Accept": "application/json",
                "Accept-Charset": "utf-8",
                "X-App-Version": AudiAPI.HDR_XAPP_VERSION,
                "X-App-Name": "myAudi",
                "User-Agent": AudiAPI.HDR_USER_AGENT,
                "Content-Type": "application/json; charset=utf-8",
            }
            asz_req_data = {
                "token": self._bearer_token_json["access_token"],
                "grant_type": "id_token",
                "stage": "live",
                "config": "myaudi",
            }
            azs_token_rsp, azs_token_rsptxt = await self._api.request(
                "POST",
                self._authorizationServerBaseURLLive + "/token",
                json.dumps(asz_req_data),
                headers=headers,
                allow_redirects=False,
                rsp_wtxt=True,
            )
            azs_token_json = json.loads(azs_token_rsptxt)
            self.audiToken = azs_token_json

            return True

        except AudiAuthError:
            raise
        except Exception:
            _LOGGER.exception("Refresh token failed")
            return False

    async def _discover_endpoints(self) -> None:
        """Resolve the dynamic client id and OIDC endpoints.

        Fetches the market configuration and the IDK openid-configuration and
        stores the client id, token endpoint, AZS/mbboauth base URLs and the
        device-authorization endpoint on the instance.
        """
        self._api.use_token(None)
        self._api.set_xclient_id(None)
        self.xclientId = None

        # get markets
        markets_json = await self._api.request(
            "GET",
            "https://content.app.my.audi.com/service/mobileapp/configurations/markets",
            None,
        )
        if (
            self._country.upper()
            not in markets_json["countries"]["countrySpecifications"]
        ):
            raise Exception("Country not found")
        self._language = markets_json["countries"]["countrySpecifications"][
            self._country.upper()
        ]["defaultLanguage"]

        # Dynamic configuration URLs
        marketcfg_url = f"https://content.app.my.audi.com/service/mobileapp/configurations/market/{self._country}/{self._language}?v=4.23.1"
        openidcfg_url = self.__get_cariad_url("/auth/v1/idk/oidc/openid-configuration")

        # get market config
        marketcfg_json = await self._api.request("GET", marketcfg_url, None)

        # use dynamic config from marketcfg
        self._client_id = "09b6cbec-cd19-4589-82fd-363dfa8c24da@apps_vw-dilab_com"
        if "idkClientIDAndroidLive" in marketcfg_json:
            self._client_id = marketcfg_json["idkClientIDAndroidLive"]

        self._authorizationServerBaseURLLive = self.__get_cariad_url("/login/v1/audi")

        if "authorizationServerBaseURLLive" in marketcfg_json:
            self._authorizationServerBaseURLLive = marketcfg_json[
                "myAudiAuthorizationServerProxyServiceURLProduction"
            ]
        self.mbbOAuthBaseURL = "https://mbboauth-1d.prd.ece.vwg-connect.com/mbbcoauth"
        if "mbbOAuthBaseURLLive" in marketcfg_json:
            self.mbbOAuthBaseURL = marketcfg_json["mbbOAuthBaseURLLive"]

        if "idkLoginServiceConfigurationURLProduction" in marketcfg_json:
            openidcfg_url = marketcfg_json["idkLoginServiceConfigurationURLProduction"]

        # get openId config
        openidcfg_json = await self._api.request("GET", openidcfg_url, None)

        self._tokenEndpoint = self.__get_cariad_url("/auth/v1/idk/oidc/token")
        if "token_endpoint" in openidcfg_json:
            self._tokenEndpoint = openidcfg_json["token_endpoint"]

        # Authorization endpoint, used by the password (authorization-code) login
        # that non-European regions still rely on.
        self._authorizationEndpoint = "https://identity.vwgroup.io/oidc/v1/authorize"
        if "authorization_endpoint" in openidcfg_json:
            self._authorizationEndpoint = openidcfg_json["authorization_endpoint"]

        # Device Authorization Grant (RFC 8628) endpoint. Discovery advertises it;
        # fall back to the well-known global identity endpoint.
        self._deviceAuthorizationEndpoint = (
            "https://identity.vwgroup.io/oidc/v1/device_authorization"
        )
        if "device_authorization_endpoint" in openidcfg_json:
            self._deviceAuthorizationEndpoint = openidcfg_json[
                "device_authorization_endpoint"
            ]

    async def login(self, user: str, password: str) -> None:
        """Username/password login (authorization-code flow).

        Retained for the regions where Audi has not (yet) enforced Play Integrity
        attestation on the token exchange. European accounts must use the Device
        Authorization Grant instead; see `request_device_code`.
        """
        _LOGGER.debug("LOGIN: Starting password login to the Audi service...")
        await self.login_request(user, password)

    async def login_request(self, user: str, password: str) -> None:
        await self._discover_endpoints()

        # generate code_challenge
        code_verifier = str(base64.urlsafe_b64encode(os.urandom(32)), "utf-8").strip(
            "="
        )
        code_challenge = str(
            base64.urlsafe_b64encode(
                sha256(code_verifier.encode("ascii", "ignore")).digest()
            ),
            "utf-8",
        ).strip("=")
        code_challenge_method = "S256"

        state = str(uuid.uuid4())
        nonce = str(uuid.uuid4())

        # login page
        headers = {
            "Accept": "application/json",
            "Accept-Charset": "utf-8",
            "X-App-Version": AudiAPI.HDR_XAPP_VERSION,
            "X-App-Name": "myAudi",
            "User-Agent": AudiAPI.HDR_USER_AGENT,
        }
        idk_data = {
            "response_type": "code",
            "client_id": self._client_id,
            "redirect_uri": "myaudi:///",
            "scope": "address profile badge birthdate birthplace nationalIdentifier nationality profession email vin phone nickname name picture mbb gallery openid",
            "state": state,
            "nonce": nonce,
            "prompt": "login",
            "code_challenge": code_challenge,
            "code_challenge_method": code_challenge_method,
            "ui_locales": "de-de de",
        }
        idk_rsp, idk_rsptxt = await self._api.request(
            "GET",
            self._authorizationEndpoint,
            None,
            headers=headers,
            params=idk_data,
            rsp_wtxt=True,
        )

        # form_data with email
        submit_data = self.get_hidden_html_input_form_data(idk_rsptxt, {"email": user})
        submit_url = self.get_post_url(idk_rsptxt, self._authorizationEndpoint)
        # send email
        email_rsp, email_rsptxt = await self._api.request(
            "POST",
            submit_url,
            submit_data,
            headers=headers,
            cookies=idk_rsp.cookies,
            allow_redirects=True,
            rsp_wtxt=True,
        )

        # form_data with password
        # 2022-01-29: new HTML response uses js to build the html form data + button.
        #             Therefore it's not possible to extract hmac and other form data.
        #             --> extract hmac from embedded js snippet.
        regex_res = re.findall('"hmac"\\s*:\\s*"[0-9a-fA-F]+"', email_rsptxt)
        if regex_res:
            submit_url = submit_url.replace("identifier", "authenticate")
            submit_data["hmac"] = regex_res[0].split(":")[1].strip('"')
            submit_data["password"] = password
        else:
            submit_data = self.get_hidden_html_input_form_data(
                email_rsptxt, {"password": password}
            )
            submit_url = self.get_post_url(email_rsptxt, submit_url)

        # send password
        pw_rsp, _pw_rsptxt = await self._api.request(
            "POST",
            submit_url,
            submit_data,
            headers=headers,
            cookies=idk_rsp.cookies,
            allow_redirects=False,
            rsp_wtxt=True,
        )

        # forward1 after pwd
        if "Location" not in pw_rsp.headers:
            raise AudiAuthError(
                f"Login redirect missing after password submission "
                f"(HTTP {pw_rsp.status}). "
                "Audi may be showing a consent or terms-of-service prompt. "
                "Please log in to myAudi via a browser or the myAudi app and "
                "accept any pending agreements, then restart the integration."
            )
        fwd1_rsp, _fwd1_rsptxt = await self._api.request(
            "GET",
            pw_rsp.headers["Location"],
            None,
            headers=headers,
            cookies=idk_rsp.cookies,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        # forward2 after pwd
        fwd2_rsp, _fwd2_rsptxt = await self._api.request(
            "GET",
            fwd1_rsp.headers["Location"],
            None,
            headers=headers,
            cookies=idk_rsp.cookies,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        # get tokens
        codeauth_rsp, _codeauth_rsptxt = await self._api.request(
            "GET",
            fwd2_rsp.headers["Location"],
            None,
            headers=headers,
            cookies=fwd2_rsp.cookies,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        authcode_parsed = urlparse(
            codeauth_rsp.headers["Location"][len("myaudi:///?") :]
        )
        authcode_strings = parse_qs(authcode_parsed.path)

        headers = {
            "Accept": "application/json",
            "Accept-Charset": "utf-8",
            "X-QMAuth": self._calculate_X_QMAuth(),
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/x-www-form-urlencoded",
        }
        tokenreq_data = {
            "client_id": self._client_id,
            "grant_type": "authorization_code",
            "code": authcode_strings["code"][0],
            "redirect_uri": "myaudi:///",
            "response_type": "token id_token",
            "code_verifier": code_verifier,
        }
        encoded_tokenreq_data = urlencode(tokenreq_data, encoding="utf-8").replace(
            "+", "%20"
        )
        _bearer_token_rsp, bearer_token_rsptxt = await self._api.request(
            "POST",
            self._tokenEndpoint,
            encoded_tokenreq_data,
            headers=headers,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        bearer_token_json = json.loads(bearer_token_rsptxt)
        if "access_token" not in bearer_token_json:
            # In Europe this is where Play Integrity attestation rejects the
            # exchange ("invalid assertion headers"); surface it clearly rather
            # than failing later with a KeyError.
            raise AudiAuthError(
                "Password login rejected at the token exchange: "
                + str(bearer_token_json.get("error", bearer_token_rsptxt[:200]))
            )
        self._bearer_token_json = bearer_token_json

        await self._finalize_session()

    async def request_device_code(self) -> dict[str, Any]:
        """Start the OAuth Device Authorization Grant (RFC 8628).

        Returns the response containing ``user_code``, ``verification_uri`` /
        ``verification_uri_complete``, ``device_code``, ``interval`` and
        ``expires_in``. The user approves the ``user_code`` in a browser. This
        grant does not require a Play Integrity attestation header.
        """
        await self._discover_endpoints()
        headers = {
            "Accept": "application/json",
            "Accept-Charset": "utf-8",
            "X-App-Version": AudiAPI.HDR_XAPP_VERSION,
            "X-App-Name": "myAudi",
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/x-www-form-urlencoded",
        }
        data = {"client_id": self._client_id, "scope": DEVICE_CODE_SCOPE}
        encoded = urlencode(data, encoding="utf-8").replace("+", "%20")
        _rsp, rsptxt = await self._api.request(
            "POST",
            self._deviceAuthorizationEndpoint,
            encoded,
            headers=headers,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        result = json.loads(rsptxt)
        if "device_code" not in result:
            raise Exception(
                "Device authorization request failed: "
                + str(result.get("error", rsptxt[:200]))
            )
        return result

    async def poll_device_token(self, device_code: str) -> str:
        """Poll the token endpoint once for a device_code grant.

        Returns one of ``"ok"``, ``"authorization_pending"``, ``"slow_down"``,
        ``"expired"``, ``"denied"`` or ``"error"``. On ``"ok"`` the IDK bearer
        token is stored and the AZS + mbboauth session tokens are derived. No
        attestation header is sent.
        """
        headers = {
            "Accept": "application/json",
            "Accept-Charset": "utf-8",
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/x-www-form-urlencoded",
        }
        data = {
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            "client_id": self._client_id,
            "device_code": device_code,
        }
        encoded = urlencode(data, encoding="utf-8").replace("+", "%20")
        _rsp, rsptxt = await self._api.request(
            "POST",
            self._tokenEndpoint,
            encoded,
            headers=headers,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        result = json.loads(rsptxt)
        if "access_token" in result:
            self._bearer_token_json = result
            await self._finalize_session()
            return "ok"
        error = result.get("error")
        mapping = {
            "authorization_pending": "authorization_pending",
            "slow_down": "slow_down",
            "expired_token": "expired",
            "access_denied": "denied",
        }
        if error in mapping:
            return mapping[error]
        _LOGGER.debug("Unexpected device token response: %s", rsptxt[:200])
        return "error"

    async def login_with_refresh_token(self, refresh_token: str) -> str:
        """Obtain a session from a stored IDK or Auth0 refresh token.

        Auth0 refresh tokens are persisted with a provider prefix so they use
        the direct Auth0 issuer instead of the attestation-gated IDK BFF.
        """
        await self._discover_endpoints()

        if refresh_token.startswith(AUTH0_REFRESH_TOKEN_PREFIX):
            raw_refresh_token = refresh_token[len(AUTH0_REFRESH_TOKEN_PREFIX) :]
            result = await self._refresh_auth0_token(raw_refresh_token)
            return AUTH0_REFRESH_TOKEN_PREFIX + result["refresh_token"]

        self._uses_auth0 = False
        headers = {
            "Accept": "application/json",
            "Accept-Charset": "utf-8",
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/x-www-form-urlencoded",
        }
        data = {
            "client_id": self._client_id,
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "response_type": "token id_token",
        }
        encoded = urlencode(data, encoding="utf-8").replace("+", "%20")
        _rsp, rsptxt = await self._api.request(
            "POST",
            self._tokenEndpoint,
            encoded,
            headers=headers,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        result = json.loads(rsptxt)
        if "access_token" not in result:
            _raise_refresh_rejected("Token refresh rejected", result, rsptxt)
        self._bearer_token_json = result
        await self._finalize_session()
        return self._bearer_token_json.get("refresh_token", refresh_token)

    def current_refresh_token(self) -> str | None:
        """Return the current provider-tagged refresh token."""
        if self._bearer_token_json is None:
            return None
        refresh_token = self._bearer_token_json.get("refresh_token")
        if refresh_token and self._uses_auth0:
            return AUTH0_REFRESH_TOKEN_PREFIX + refresh_token
        return refresh_token

    @property
    def uses_auth0(self) -> bool:
        """Return whether this session uses the modern CARIAD Auth0 API."""
        return self._uses_auth0

    def get_id_token_subject(self) -> str | None:
        """Return a stable account identifier (email or sub) from the id token."""
        if self._bearer_token_json is None:
            return None
        id_token = self._bearer_token_json.get("id_token")
        if not id_token:
            return None
        try:
            segment = id_token.split(".")[1]
            segment += "=" * (-len(segment) % 4)
            payload = json.loads(base64.urlsafe_b64decode(segment))
        except (ValueError, IndexError, json.JSONDecodeError):
            return None
        return payload.get("email") or payload.get("sub")

    async def _finalize_session(self) -> None:
        """Derive the AZS and mbboauth tokens from the current IDK bearer token."""

        # AZS token
        headers = {
            "Accept": "application/json",
            "Accept-Charset": "utf-8",
            "X-App-Version": AudiAPI.HDR_XAPP_VERSION,
            "X-App-Name": "myAudi",
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/json; charset=utf-8",
        }
        asz_req_data = {
            "token": self._bearer_token_json["access_token"],
            "grant_type": "id_token",
            "stage": "live",
            "config": "myaudi",
        }
        azs_token_rsp, azs_token_rsptxt = await self._api.request(
            "POST",
            self._authorizationServerBaseURLLive + "/token",
            json.dumps(asz_req_data),
            headers=headers,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        azs_token_json = json.loads(azs_token_rsptxt)
        self.audiToken = azs_token_json

        # mbboauth client register
        headers = {
            "Accept": "application/json",
            "Accept-Charset": "utf-8",
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/json; charset=utf-8",
        }
        mbboauth_reg_data = {
            "client_name": "SM-A405FN",
            "platform": "google",
            "client_brand": "Audi",
            "appName": "myAudi",
            "appVersion": AudiAPI.HDR_XAPP_VERSION,
            "appId": "de.myaudi.mobile.assistant",
        }
        mbboauth_client_reg_rsp, mbboauth_client_reg_rsptxt = await self._api.request(
            "POST",
            self.mbbOAuthBaseURL + "/mobile/register/v1",
            json.dumps(mbboauth_reg_data),
            headers=headers,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        mbboauth_client_reg_json = json.loads(mbboauth_client_reg_rsptxt)
        self.xclientId = mbboauth_client_reg_json["client_id"]
        self._api.set_xclient_id(self.xclientId)

        # mbboauth auth
        headers = {
            "Accept": "application/json",
            "Accept-Charset": "utf-8",
            "User-Agent": AudiAPI.HDR_USER_AGENT,
            "Content-Type": "application/x-www-form-urlencoded",
            "X-Client-ID": self.xclientId,
        }
        mbboauth_auth_data = {
            "grant_type": "id_token",
            "token": self._bearer_token_json["id_token"],
            "scope": "sc2:fal",
        }
        encoded_mbboauth_auth_data = urlencode(
            mbboauth_auth_data, encoding="utf-8"
        ).replace("+", "%20")
        mbboauth_auth_rsp, mbboauth_auth_rsptxt = await self._api.request(
            "POST",
            self.mbbOAuthBaseURL + "/mobile/oauth2/v1/token",
            encoded_mbboauth_auth_data,
            headers=headers,
            allow_redirects=False,
            rsp_wtxt=True,
        )
        mbboauth_auth_json = json.loads(mbboauth_auth_rsptxt)
        if "access_token" not in mbboauth_auth_json:
            # Fail here rather than storing the error body as a token: otherwise
            # vwToken silently becomes {"error": ...} and only surfaces much later
            # as KeyError('access_token') in get_tripdata() or a TypeError in
            # get_climater(), far from the real cause.
            error_description = mbboauth_auth_json.get(
                "error_description",
                mbboauth_auth_rsptxt[:200],
            )

            raise AudiAuthError(f"mbboauth token exchange failed: {error_description}")
        # store token and expiration time
        self.mbboauthToken = mbboauth_auth_json

        # mbboauth refresh (app immediately refreshes the token)
        # The MBB OAuth auth response no longer always includes a refresh_token.
        # Skip the immediate refresh if absent and use the auth token directly.
        if "refresh_token" in mbboauth_auth_json:
            headers = {
                "Accept": "application/json",
                "Accept-Charset": "utf-8",
                "User-Agent": AudiAPI.HDR_USER_AGENT,
                "Content-Type": "application/x-www-form-urlencoded",
                "X-Client-ID": self.xclientId,
            }
            mbboauth_refresh_data = {
                "grant_type": "refresh_token",
                "token": mbboauth_auth_json["refresh_token"],
                "scope": "sc2:fal",
                # "vin": vin,  << App uses a dedicated VIN here, but it works without, don't know
            }
            encoded_mbboauth_refresh_data = urlencode(
                mbboauth_refresh_data, encoding="utf-8"
            ).replace("+", "%20")
            mbboauth_refresh_rsp, mbboauth_refresh_rsptxt = await self._api.request(
                "POST",
                self.mbbOAuthBaseURL + "/mobile/oauth2/v1/token",
                encoded_mbboauth_refresh_data,
                headers=headers,
                allow_redirects=False,
                cookies=mbboauth_client_reg_rsp.cookies,
                rsp_wtxt=True,
            )
            # this code is the old "vwToken"
            refreshed = json.loads(mbboauth_refresh_rsptxt)
            if "access_token" not in refreshed:
                _raise_refresh_rejected(
                    "mbboauth refresh rejected", refreshed, mbboauth_refresh_rsptxt
                )
            self.vwToken = refreshed
        else:
            _LOGGER.debug(
                "mbboauth: no refresh_token in auth response, using auth token directly as vwToken"
            )
            self.vwToken = mbboauth_auth_json

    def _generate_security_pin_hash(self, challenge: str) -> str:
        if self._spin is None:
            raise Exception("sPin is required to perform this action")

        pin = to_byte_array(self._spin)
        byteChallenge = to_byte_array(challenge)
        b = bytes(pin + byteChallenge)
        return sha512(b).hexdigest().upper()


__all__ = ["AudiAuthError", "AudiService", "AudiTokenRefreshError"]
