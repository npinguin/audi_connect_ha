"""Support for Audi Connect sensors."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

from homeassistant.components.sensor import (
    RestoreSensor,
    SensorDeviceClass,
    SensorEntity,
    SensorEntityDescription,
    SensorStateClass,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import (
    PERCENTAGE,
    EntityCategory,
    UnitOfElectricCurrent,
    UnitOfLength,
    UnitOfPower,
    UnitOfTemperature,
    UnitOfTime,
)
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.event import async_track_time_interval
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from . import AudiRuntimeData
from .audi_entity import AudiEntity, entity_unique_id, should_create_entity
from .coordinator import AudiDataUpdateCoordinator
from .freshness import usable_vehicle_timestamp, vehicle_age_minutes, vehicle_freshness
from .local_extensions import get_local_dealer
from .util import parse_datetime


@dataclass(frozen=True, kw_only=True)
class AudiSensorEntityDescription(SensorEntityDescription):
    """Describes an Audi sensor entity."""

    attr_key: str
    # The car's own capability id, where one maps cleanly. Given one, entity
    # creation follows the capability rather than whether this poll carried
    # the value, so a partial poll leaves the entity unavailable instead of
    # deleting it.
    capability: str | None = None
    value_fn: Callable[[Any], Any] | None = None
    extra_attrs_fn: Callable[[Any], dict[str, Any]] | None = None
    unit_fn: Callable[[Any], str | None] | None = None


def _trip_data_value(vehicle: Any, attr_key: str) -> Any:
    """Extract timestamp from trip data dict as the sensor state."""
    td = getattr(vehicle, attr_key, None)
    if td and isinstance(td, dict):
        return parse_datetime(td.get("timestamp"))
    return None


def _trip_data_attrs(vehicle: Any, attr_key: str) -> dict[str, Any]:
    """Extract extra attributes from trip data dict."""
    td = getattr(vehicle, attr_key, None)
    if not td or not isinstance(td, dict):
        return {}
    return {
        "averageElectricEngineConsumption": td.get("averageElectricEngineConsumption"),
        "averageFuelConsumption": td.get("averageFuelConsumption"),
        "averageSpeed": td.get("averageSpeed"),
        "mileage": td.get("mileage"),
        "overallMileage": td.get("overallMileage"),
        "startMileage": td.get("startMileage"),
        "traveltime": td.get("traveltime"),
        "tripID": td.get("tripID"),
        "zeroEmissionDistance": td.get("zeroEmissionDistance"),
    }


def _active_profile_attrs(vehicle: Any) -> dict[str, Any]:
    """Everything needed to see why the car is charging to the number it is."""
    attrs: dict[str, Any] = {
        "profile_id": getattr(vehicle, "active_charging_profile_id", None),
        "profile_name": getattr(vehicle, "active_charging_profile_name", None),
        "min_soc_pct": getattr(vehicle, "active_charging_profile_min_soc", None),
        "global_target_soc_pct": getattr(vehicle, "target_state_of_charge", None),
        "preferred_charging_time_start": getattr(
            vehicle, "preferred_charging_time_start", None
        ),
        "preferred_charging_time_end": getattr(
            vehicle, "preferred_charging_time_end", None
        ),
        "preferred_charging_time_enabled": getattr(
            vehicle, "preferred_charging_time_enabled", None
        ),
        "profiles": getattr(vehicle, "charging_profiles", None),
    }
    return {k: v for k, v in attrs.items() if v is not None}


def _climatisation_timer_attrs(vehicle: Any) -> dict[str, Any]:
    """Safe, bounded climate timers returned by the car (not inferred)."""
    timers = getattr(vehicle, "climatisation_timers", None)
    return {
        "timers": timers[:12] if isinstance(timers, list) else [],
        "start_timezone": "vehicle_local_not_inferred",
        "meaning": "Configured climate timers, not proof that the car will start",
    }


def _charging_timer_attrs(vehicle: Any) -> dict[str, Any]:
    attrs: dict[str, Any] = {
        "timers": getattr(vehicle, "charging_timers", None),
        "next_departure": getattr(vehicle, "next_charging_timer_departure", None),
    }
    return {k: v for k, v in attrs.items() if v is not None}


def _model_attrs(vehicle: Any) -> dict[str, Any]:
    """Disclose when Model is sourced from a user nickname, not Audi metadata."""
    return {
        "model_source": getattr(vehicle, "model_source", "unavailable"),
        "model_year": getattr(vehicle, "model_year", "") or None,
    }


def _park_time_attrs(vehicle: Any) -> dict[str, Any]:
    """A GPS-position capture is an approximation, not an engine-off event."""
    source = getattr(vehicle, "park_time_source", "unavailable")
    return {
        "time_source": source,
        "estimated": source == "last_parked_position_capture_estimate",
        "meaning": (
            "Time Audi reported the last parked location; not verified time parked"
            if source == "last_parked_position_capture_estimate"
            else "Vehicle parking clock"
            if source == "vehicle_parking_clock"
            else "No parking timestamp reported"
        ),
    }


SENSOR_DESCRIPTIONS: tuple[AudiSensorEntityDescription, ...] = (
    AudiSensorEntityDescription(
        key="last_update_time",
        attr_key="last_update_time",
        name="Last Update",
        icon="mdi:update",
        device_class=SensorDeviceClass.TIMESTAMP,
    ),
    AudiSensorEntityDescription(
        key="shortterm_current",
        attr_key="shortterm_current",
        name="ShortTerm Trip Data",
        device_class=SensorDeviceClass.TIMESTAMP,
        value_fn=lambda v: _trip_data_value(v, "shortterm_current"),
        extra_attrs_fn=lambda v: _trip_data_attrs(v, "shortterm_current"),
    ),
    AudiSensorEntityDescription(
        key="shortterm_reset",
        attr_key="shortterm_reset",
        name="ShortTerm Trip User Reset",
        device_class=SensorDeviceClass.TIMESTAMP,
        value_fn=lambda v: _trip_data_value(v, "shortterm_reset"),
        extra_attrs_fn=lambda v: _trip_data_attrs(v, "shortterm_reset"),
    ),
    AudiSensorEntityDescription(
        key="longterm_current",
        attr_key="longterm_current",
        name="LongTerm Trip Data",
        device_class=SensorDeviceClass.TIMESTAMP,
        value_fn=lambda v: _trip_data_value(v, "longterm_current"),
        extra_attrs_fn=lambda v: _trip_data_attrs(v, "longterm_current"),
    ),
    AudiSensorEntityDescription(
        key="longterm_reset",
        attr_key="longterm_reset",
        name="LongTerm Trip User Reset",
        device_class=SensorDeviceClass.TIMESTAMP,
        value_fn=lambda v: _trip_data_value(v, "longterm_reset"),
        extra_attrs_fn=lambda v: _trip_data_attrs(v, "longterm_reset"),
    ),
    AudiSensorEntityDescription(
        key="model",
        attr_key="model",
        name="Model",
        icon="mdi:car-info",
        extra_attrs_fn=_model_attrs,
    ),
    AudiSensorEntityDescription(
        key="mileage",
        attr_key="mileage",
        name="Mileage",
        icon="mdi:counter",
        native_unit_of_measurement=UnitOfLength.KILOMETERS,
        state_class=SensorStateClass.TOTAL_INCREASING,
        device_class=SensorDeviceClass.DISTANCE,
        entity_category=EntityCategory.DIAGNOSTIC,
        suggested_display_precision=0,
    ),
    AudiSensorEntityDescription(
        key="service_adblue_distance",
        attr_key="service_adblue_distance",
        name="AdBlue range",
        icon="mdi:map-marker-distance",
        native_unit_of_measurement=UnitOfLength.KILOMETERS,
        device_class=SensorDeviceClass.DISTANCE,
        suggested_display_precision=0,
    ),
    AudiSensorEntityDescription(
        key="range",
        attr_key="range",
        name="Range",
        icon="mdi:map-marker-distance",
        native_unit_of_measurement=UnitOfLength.KILOMETERS,
        device_class=SensorDeviceClass.DISTANCE,
        suggested_display_precision=0,
    ),
    AudiSensorEntityDescription(
        key="hybrid_range",
        attr_key="hybrid_range",
        name="hybrid Range",
        icon="mdi:map-marker-distance",
        native_unit_of_measurement=UnitOfLength.KILOMETERS,
        device_class=SensorDeviceClass.DISTANCE,
        suggested_display_precision=0,
    ),
    AudiSensorEntityDescription(
        key="service_inspection_time",
        attr_key="service_inspection_time",
        name="Service inspection time",
        icon="mdi:room-service-outline",
        native_unit_of_measurement=UnitOfTime.DAYS,
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    AudiSensorEntityDescription(
        key="service_inspection_distance",
        attr_key="service_inspection_distance",
        name="Service inspection distance",
        icon="mdi:room-service-outline",
        native_unit_of_measurement=UnitOfLength.KILOMETERS,
        device_class=SensorDeviceClass.DISTANCE,
        entity_category=EntityCategory.DIAGNOSTIC,
        suggested_display_precision=0,
    ),
    AudiSensorEntityDescription(
        key="oil_change_time",
        attr_key="oil_change_time",
        name="Oil change time",
        icon="mdi:oil",
        native_unit_of_measurement=UnitOfTime.DAYS,
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    AudiSensorEntityDescription(
        key="oil_change_distance",
        attr_key="oil_change_distance",
        name="Oil change distance",
        icon="mdi:oil",
        native_unit_of_measurement=UnitOfLength.KILOMETERS,
        device_class=SensorDeviceClass.DISTANCE,
        entity_category=EntityCategory.DIAGNOSTIC,
        suggested_display_precision=0,
    ),
    AudiSensorEntityDescription(
        key="oil_level",
        attr_key="oil_level",
        name="Oil level",
        icon="mdi:oil",
        native_unit_of_measurement=PERCENTAGE,
    ),
    AudiSensorEntityDescription(
        key="charging_state",
        attr_key="charging_state",
        name="Charging state",
        icon="mdi:car-battery",
    ),
    AudiSensorEntityDescription(
        key="charging_mode",
        attr_key="charging_mode",
        name="Charging mode",
    ),
    AudiSensorEntityDescription(
        key="charging_type",
        attr_key="charging_type",
        name="Charging type",
    ),
    AudiSensorEntityDescription(
        key="energy_flow",
        attr_key="energy_flow",
        name="Energy flow",
    ),
    AudiSensorEntityDescription(
        key="max_charge_current",
        attr_key="max_charge_current",
        name="Max charge current",
        icon="mdi:current-ac",
        native_unit_of_measurement=UnitOfElectricCurrent.AMPERE,
        device_class=SensorDeviceClass.CURRENT,
    ),
    AudiSensorEntityDescription(
        key="charging_current_limit_a",
        attr_key="charging_current_limit_a",
        capability="charging",
        name="Charging AC current limit",
        icon="mdi:current-ac",
        native_unit_of_measurement=UnitOfElectricCurrent.AMPERE,
        device_class=SensorDeviceClass.CURRENT,
    ),
    AudiSensorEntityDescription(
        key="charging_current_limit_mode",
        attr_key="charging_current_limit_mode",
        capability="charging",
        name="Charging current mode",
        icon="mdi:ev-station",
    ),
    AudiSensorEntityDescription(
        key="charging_plug_auto_unlock",
        attr_key="charging_plug_auto_unlock",
        capability="charging",
        name="Unlock charging plug after charge",
        icon="mdi:ev-plug-type2",
    ),
    AudiSensorEntityDescription(
        key="vehicle_reported_online",
        attr_key="vehicle_reported_online",
        capability="readiness",
        name="Vehicle reported connectivity",
        icon="mdi:car-connected",
    ),
    AudiSensorEntityDescription(
        key="vehicle_reported_active",
        attr_key="vehicle_reported_active",
        capability="readiness",
        name="Vehicle reported activity",
        icon="mdi:car-clock",
    ),
    AudiSensorEntityDescription(
        key="primary_engine_type",
        attr_key="primary_engine_type",
        name="Primary engine type",
        icon="mdi:engine",
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    AudiSensorEntityDescription(
        key="secondary_engine_type",
        attr_key="secondary_engine_type",
        name="Secondary engine type",
        icon="mdi:engine",
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    AudiSensorEntityDescription(
        key="primary_engine_range",
        attr_key="primary_engine_range",
        name="Primary engine range",
        icon="mdi:map-marker-distance",
        native_unit_of_measurement=UnitOfLength.KILOMETERS,
        device_class=SensorDeviceClass.DISTANCE,
        suggested_display_precision=0,
    ),
    AudiSensorEntityDescription(
        key="secondary_engine_range",
        attr_key="secondary_engine_range",
        name="Secondary engine range",
        icon="mdi:map-marker-distance",
        native_unit_of_measurement=UnitOfLength.KILOMETERS,
        device_class=SensorDeviceClass.DISTANCE,
        suggested_display_precision=0,
    ),
    AudiSensorEntityDescription(
        key="primary_engine_range_percent",
        attr_key="primary_engine_range_percent",
        name="Primary engine Percent",
        icon="mdi:gauge",
        native_unit_of_measurement=PERCENTAGE,
    ),
    AudiSensorEntityDescription(
        key="car_type",
        attr_key="car_type",
        name="Car Type",
        icon="mdi:car-info",
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    AudiSensorEntityDescription(
        key="secondary_engine_range_percent",
        attr_key="secondary_engine_range_percent",
        name="Secondary engine Percent",
        icon="mdi:gauge",
        native_unit_of_measurement=PERCENTAGE,
    ),
    AudiSensorEntityDescription(
        key="charging_power",
        attr_key="charging_power",
        name="Charging power",
        icon="mdi:flash",
        native_unit_of_measurement=UnitOfPower.KILO_WATT,
        device_class=SensorDeviceClass.POWER,
    ),
    AudiSensorEntityDescription(
        key="actual_charge_rate",
        attr_key="actual_charge_rate",
        name="Charging rate",
        icon="mdi:electron-framework",
        unit_fn=lambda v: getattr(v, "actual_charge_rate_unit", None),
    ),
    AudiSensorEntityDescription(
        key="tank_level",
        attr_key="tank_level",
        name="Tank level",
        icon="mdi:gauge",
        native_unit_of_measurement=PERCENTAGE,
    ),
    AudiSensorEntityDescription(
        key="state_of_charge",
        attr_key="state_of_charge",
        name="State of charge",
        native_unit_of_measurement=PERCENTAGE,
        device_class=SensorDeviceClass.BATTERY,
    ),
    AudiSensorEntityDescription(
        key="remaining_charging_time",
        attr_key="remaining_charging_time",
        name="Remaining charge time",
        icon="mdi:battery-charging",
        unit_fn=lambda v: getattr(v, "remaining_charging_time_unit", None),
    ),
    AudiSensorEntityDescription(
        key="charging_complete_time",
        attr_key="charging_complete_time",
        name="Charging Complete Time",
        icon="mdi:battery-charging",
        device_class=SensorDeviceClass.TIMESTAMP,
    ),
    AudiSensorEntityDescription(
        key="target_state_of_charge",
        attr_key="target_state_of_charge",
        name="Target State of charge",
        icon="mdi:ev-station",
        native_unit_of_measurement=PERCENTAGE,
    ),
    AudiSensorEntityDescription(
        key="external_power",
        attr_key="external_power",
        name="External Power",
        icon="mdi:ev-station",
    ),
    AudiSensorEntityDescription(
        key="plug_led_color",
        attr_key="plug_led_color",
        name="Plug LED Color",
        icon="mdi:ev-plug-type1",
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    AudiSensorEntityDescription(
        key="doors_trunk_status",
        attr_key="doors_trunk_status",
        name="Doors/trunk state",
        icon="mdi:car-door",
    ),
    AudiSensorEntityDescription(
        key="climatisation_state",
        attr_key="climatisation_state",
        name="Climatisation state",
        icon="mdi:air-conditioner",
    ),
    AudiSensorEntityDescription(
        key="outdoor_temperature",
        attr_key="outdoor_temperature",
        name="Outdoor Temperature",
        icon="mdi:temperature-celsius",
        native_unit_of_measurement=UnitOfTemperature.CELSIUS,
        device_class=SensorDeviceClass.TEMPERATURE,
    ),
    AudiSensorEntityDescription(
        key="park_time",
        attr_key="park_time",
        capability="parkingPosition",
        name="Park Time",
        icon="mdi:car-clock",
        device_class=SensorDeviceClass.TIMESTAMP,
        extra_attrs_fn=_park_time_attrs,
    ),
    AudiSensorEntityDescription(
        key="position_last_updated",
        attr_key="position_last_updated",
        capability="parkingPosition",
        name="Position Last Updated",
        icon="mdi:map-marker-clock",
        device_class=SensorDeviceClass.TIMESTAMP,
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    AudiSensorEntityDescription(
        key="remaining_climatisation_time",
        attr_key="remaining_climatisation_time",
        name="Remaining Climatisation Time",
        icon="mdi:fan-clock",
        native_unit_of_measurement=UnitOfTime.MINUTES,
    ),
    AudiSensorEntityDescription(
        key="preheater_duration",
        attr_key="preheater_duration",
        name="Preheater runtime",
        icon="mdi:clock",
        native_unit_of_measurement=UnitOfTime.MINUTES,
    ),
    AudiSensorEntityDescription(
        key="preheater_remaining",
        attr_key="preheater_remaining",
        name="Preheater remaining",
        icon="mdi:clock",
        native_unit_of_measurement=UnitOfTime.MINUTES,
    ),
    AudiSensorEntityDescription(
        key="active_charging_profile_target_soc",
        attr_key="active_charging_profile_target_soc",
        name="Active Charging Profile Target SoC",
        icon="mdi:map-marker-check",
        native_unit_of_measurement=PERCENTAGE,
        state_class=SensorStateClass.MEASUREMENT,
        extra_attrs_fn=_active_profile_attrs,
    ),
    AudiSensorEntityDescription(
        key="active_charging_profile_name",
        attr_key="active_charging_profile_name",
        name="Active Charging Profile",
        icon="mdi:map-marker",
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    AudiSensorEntityDescription(
        key="active_charging_profile_min_soc",
        attr_key="active_charging_profile_min_soc",
        name="Active Charging Profile Min SoC",
        icon="mdi:battery-alert-variant-outline",
        native_unit_of_measurement=PERCENTAGE,
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    AudiSensorEntityDescription(
        key="preferred_charging_time_start",
        attr_key="preferred_charging_time_start",
        name="Preferred Charging Window Start",
        icon="mdi:clock-start",
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    AudiSensorEntityDescription(
        key="preferred_charging_time_end",
        attr_key="preferred_charging_time_end",
        name="Preferred Charging Window End",
        icon="mdi:clock-end",
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    AudiSensorEntityDescription(
        key="climatisation_timer_enabled_count",
        attr_key="climatisation_timer_enabled_count",
        capability="climatisationTimers",
        name="Climate Timers Enabled",
        icon="mdi:calendar-clock",
        extra_attrs_fn=_climatisation_timer_attrs,
    ),
    AudiSensorEntityDescription(
        key="next_climatisation_timer_local",
        attr_key="next_climatisation_timer_local",
        capability="climatisationTimers",
        name="Next Climate Timer (Car Local Time)",
        icon="mdi:calendar-start",
        extra_attrs_fn=_climatisation_timer_attrs,
    ),
    AudiSensorEntityDescription(
        key="charging_timer_enabled_count",
        attr_key="charging_timer_enabled_count",
        name="Charging Timers Enabled",
        icon="mdi:timer-cog-outline",
        entity_category=EntityCategory.DIAGNOSTIC,
        extra_attrs_fn=_charging_timer_attrs,
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    runtime_data: AudiRuntimeData = config_entry.runtime_data
    entities: list[SensorEntity] = []

    for config_vehicle in runtime_data.account.config_vehicles:
        vehicle = config_vehicle.vehicle
        # Always expose freshness on the device, even if current Audi data is
        # stale or unavailable. Existing Last Update keeps its unique ID.
        entities.extend(
            (
                AudiVehicleFreshnessSensor(runtime_data.coordinator, vehicle),
                AudiVehicleAgeSensor(runtime_data.coordinator, vehicle),
                AudiCloudLastPollSensor(runtime_data.coordinator, vehicle),
            )
        )
        # Add the local dealer sensor even before the user configures it.
        # Hiding it until data exists made this feature effectively invisible.
        entities.append(
            AudiLocalDealerSensor(runtime_data.coordinator, vehicle, config_entry)
        )
        entities.append(
            AudiServiceOverviewSensor(runtime_data.coordinator, vehicle, config_entry)
        )
        for description in SENSOR_DESCRIPTIONS:
            if should_create_entity(
                hass,
                "sensor",
                description.key,
                vehicle,
                description.attr_key,
                description.capability,
            ):
                entities.append(
                    AudiSensor(runtime_data.coordinator, description, vehicle)
                )

    # Add account-level API rate limit sensor, attached to the first vehicle.
    if runtime_data.account.config_vehicles:
        first_vehicle = runtime_data.account.config_vehicles[0].vehicle
        entities.append(
            AudiApiRateLimitSensor(
                runtime_data.coordinator,
                config_entry.entry_id,
                first_vehicle,
            )
        )

    async_add_entities(entities)


class AudiSensor(AudiEntity, SensorEntity):
    """Representation of an Audi sensor."""

    entity_description: AudiSensorEntityDescription

    def __init__(
        self,
        coordinator: AudiDataUpdateCoordinator,
        description: AudiSensorEntityDescription,
        vehicle: Any,
    ) -> None:
        super().__init__(coordinator, vehicle)
        self.entity_description = description
        self._attr_unique_id = entity_unique_id(vehicle, "sensor", description.key)

    @property
    def native_value(self) -> Any:
        if self.entity_description.value_fn is not None:
            return self.entity_description.value_fn(self._vehicle)
        return getattr(self._vehicle, self.entity_description.attr_key, None)

    @property
    def native_unit_of_measurement(self) -> str | None:
        if self.entity_description.unit_fn is not None:
            dynamic = self.entity_description.unit_fn(self._vehicle)
            if dynamic is not None:
                return dynamic
        return self.entity_description.native_unit_of_measurement

    @property
    def extra_state_attributes(self) -> dict[str, Any] | None:
        if self.entity_description.extra_attrs_fn is not None:
            return self.entity_description.extra_attrs_fn(self._vehicle)
        return None


class _AudiClockAwareSensor(AudiEntity, SensorEntity):
    """Refresh display age even when Audi cloud polling fails."""

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        self.async_on_remove(
            async_track_time_interval(
                self.hass, self._async_clock_tick, timedelta(minutes=5)
            )
        )

    @callback
    def _async_clock_tick(self, _now: datetime) -> None:
        self.async_write_ha_state()


class AudiVehicleFreshnessSensor(_AudiClockAwareSensor):
    """Readable freshness status of the newest car telemetry timestamp."""

    _attr_name = "Vehicle data freshness"
    _attr_icon = "mdi:clock-check-outline"
    _attr_device_class = SensorDeviceClass.ENUM
    _attr_options = ["fresh", "delayed", "stale", "unknown"]

    def __init__(self, coordinator: AudiDataUpdateCoordinator, vehicle: Any) -> None:
        super().__init__(coordinator, vehicle)
        self._attr_unique_id = entity_unique_id(
            vehicle, "sensor", "vehicle_data_freshness"
        )

    @property
    def available(self) -> bool:
        # Stale/offline car data must remain visible instead of going unavailable.
        return True

    @property
    def native_value(self) -> str:
        return vehicle_freshness(getattr(self._vehicle, "last_update_time", None))

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        timestamp = usable_vehicle_timestamp(
            getattr(self._vehicle, "last_update_time", None)
        )
        last_success = getattr(self.coordinator, "last_cloud_poll_success", None)
        last_attempt = getattr(self.coordinator, "last_cloud_poll_attempt", None)
        return {
            "vehicle_last_update": timestamp.isoformat() if timestamp else None,
            "vehicle_age_minutes": vehicle_age_minutes(
                getattr(self._vehicle, "last_update_time", None)
            ),
            "cloud_last_successful_poll": (
                last_success.isoformat() if isinstance(last_success, datetime) else None
            ),
            "cloud_last_attempt": (
                last_attempt.isoformat() if isinstance(last_attempt, datetime) else None
            ),
            "last_cloud_poll_succeeded": bool(
                getattr(self.coordinator, "last_update_success", False)
            ),
            "freshness_basis": "newest_vehicle_timestamp_not_all_fields",
        }


class AudiVehicleAgeSensor(_AudiClockAwareSensor):
    """Age of the newest vehicle data timestamp, independent of cloud login."""

    _attr_name = "Vehicle data age"
    _attr_icon = "mdi:timer-sand"
    _attr_native_unit_of_measurement = UnitOfTime.MINUTES
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(self, coordinator: AudiDataUpdateCoordinator, vehicle: Any) -> None:
        super().__init__(coordinator, vehicle)
        self._attr_unique_id = entity_unique_id(vehicle, "sensor", "vehicle_data_age")

    @property
    def available(self) -> bool:
        return True

    @property
    def native_value(self) -> int | None:
        return vehicle_age_minutes(getattr(self._vehicle, "last_update_time", None))


class AudiCloudLastPollSensor(AudiEntity, SensorEntity):
    """Last actual successful cloud poll, never mistaken for vehicle telemetry."""

    _attr_name = "Cloud last successful poll"
    _attr_icon = "mdi:cloud-check-outline"
    _attr_device_class = SensorDeviceClass.TIMESTAMP

    def __init__(self, coordinator: AudiDataUpdateCoordinator, vehicle: Any) -> None:
        super().__init__(coordinator, vehicle)
        self._attr_unique_id = entity_unique_id(
            vehicle, "sensor", "cloud_last_successful_poll"
        )

    @property
    def available(self) -> bool:
        return True

    @property
    def native_value(self) -> datetime | None:
        return getattr(self.coordinator, "last_cloud_poll_success", None)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        attempt = getattr(self.coordinator, "last_cloud_poll_attempt", None)
        return {
            "last_attempt": attempt.isoformat()
            if isinstance(attempt, datetime)
            else None,
            "last_poll_succeeded": bool(
                getattr(self.coordinator, "last_update_success", False)
            ),
        }


class AudiLocalDealerSensor(AudiEntity, SensorEntity):
    """Visible, locally managed dealership details on the Audi device.

    The source connector has inspection dates, but no verified dealer lookup.
    Never claim that manual dealer metadata came from the Audi cloud.
    """

    _attr_name = "Dealer (local)"
    _attr_icon = "mdi:store"

    def __init__(
        self, coordinator: AudiDataUpdateCoordinator, vehicle: Any, entry: ConfigEntry
    ) -> None:
        super().__init__(coordinator, vehicle)
        self._entry = entry
        self._attr_unique_id = entity_unique_id(vehicle, "sensor", "local_dealer")

    @property
    def available(self) -> bool:
        return True

    @property
    def _local_data(self) -> dict[str, str]:
        return get_local_dealer(self._entry.options, self._vehicle.vin)

    @property
    def native_value(self) -> str:
        return self._local_data.get("dealer_name", "Not configured")

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        data = self._local_data
        return {
            "source": "Home Assistant local configuration (not Audi)",
            "configured": bool(data),
            "configuration_path": "Audi Connect > Configure > Edit dealer and local service details",
            **{key: value for key, value in data.items() if key != "dealer_name"},
        }


class AudiServiceOverviewSensor(AudiEntity, SensorEntity):
    """Car-sourced maintenance combined with optional local appointment data."""

    _attr_name = "Service overview"
    _attr_icon = "mdi:car-wrench"

    def __init__(
        self, coordinator: AudiDataUpdateCoordinator, vehicle: Any, entry: ConfigEntry
    ) -> None:
        super().__init__(coordinator, vehicle)
        self._entry = entry
        self._attr_unique_id = entity_unique_id(vehicle, "sensor", "service_overview")

    @property
    def available(self) -> bool:
        # A local appointment remains useful even if Audi cloud is down.
        return True

    @property
    def native_value(self) -> str:
        inspection = getattr(self._vehicle, "service_inspection_time", None)
        oil = getattr(self._vehicle, "oil_change_time", None)
        numbers = [
            value
            for value in (inspection, oil)
            if isinstance(value, (float, int)) and not isinstance(value, bool)
        ]
        if any(value <= 0 for value in numbers):
            return "overdue"
        if any(value <= 30 for value in numbers):
            return "due_soon"
        if numbers:
            return "scheduled"
        data = get_local_dealer(self._entry.options, self._vehicle.vin)
        return "appointment_recorded" if data.get("next_service_date") else "unknown"

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        data = get_local_dealer(self._entry.options, self._vehicle.vin)
        return {
            "inspection_due_days": getattr(
                self._vehicle, "service_inspection_time", None
            ),
            "inspection_due_km": getattr(
                self._vehicle, "service_inspection_distance", None
            ),
            "oil_service_due_days": getattr(self._vehicle, "oil_change_time", None),
            "oil_service_due_km": getattr(self._vehicle, "oil_change_distance", None),
            "next_appointment_local": data.get("next_service_date"),
            "warranty_expiry_local": data.get("warranty_expiry"),
            "maintenance_source": "Audi vehicleHealthInspection when reported",
            "appointment_source": "Home Assistant local configuration, not Audi",
        }


class AudiApiRateLimitSensor(AudiEntity, RestoreSensor):
    """Account-level sensor exposing the Vcf-Remaining-Calls API rate limit."""

    _attr_name = "API requests remaining"
    _attr_icon = "mdi:api"
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(
        self,
        coordinator: AudiDataUpdateCoordinator,
        entry_id: str,
        vehicle: Any,
    ) -> None:
        super().__init__(coordinator, vehicle)
        self._attr_unique_id = f"{entry_id}_api_requests_remaining"
        self._restored_native_value: int | None = None
        self._restored_last_observed: str | None = None

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        api = self.coordinator.account.connection._audi_service._api
        if api.vcf_remaining_calls is not None:
            return

        if (restored := await self.async_get_last_sensor_data()) is not None:
            value = restored.native_value
            if isinstance(value, int) and not isinstance(value, bool):
                self._restored_native_value = value

        if (last_state := await self.async_get_last_state()) is None:
            return

        # Supports the first restart after upgrading from a version that did
        # not previously store SensorExtraStoredData through RestoreSensor.
        if self._restored_native_value is None and last_state.state.isdigit():
            self._restored_native_value = int(last_state.state)

        last_observed = last_state.attributes.get("last_observed")
        if isinstance(last_observed, str):
            self._restored_last_observed = last_observed

    @property
    def native_value(self) -> int | None:
        api = self.coordinator.account.connection._audi_service._api
        if api.vcf_remaining_calls is not None:
            return api.vcf_remaining_calls
        return self._restored_native_value

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        api = self.coordinator.account.connection._audi_service._api
        if api.vcf_remaining_calls_last_observed is not None:
            return {
                "last_observed": api.vcf_remaining_calls_last_observed.isoformat(),
                # Avoid an attribute named "restored"; Home Assistant's frontend treats
                # stateObj.attributes.restored as the marker for a restored/orphaned entity.
                "value_restored": False,
            }

        if self._restored_native_value is None:
            return {}

        attrs: dict[str, Any] = {
            # Avoid an attribute named "restored"; Home Assistant's frontend treats
            # stateObj.attributes.restored as the marker for a restored/orphaned entity.
            "value_restored": True,
        }
        if self._restored_last_observed is not None:
            attrs["last_observed"] = self._restored_last_observed
        return attrs


__all__ = [
    "AudiApiRateLimitSensor",
    "AudiCloudLastPollSensor",
    "AudiLocalDealerSensor",
    "AudiSensor",
    "AudiVehicleAgeSensor",
    "AudiVehicleFreshnessSensor",
    "async_setup_entry",
]
