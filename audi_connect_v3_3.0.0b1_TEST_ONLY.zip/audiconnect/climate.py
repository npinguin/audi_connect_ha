"""Support for Audi Connect climate entities."""

from __future__ import annotations

import contextlib
from typing import Any

from homeassistant.components.climate import (
    ClimateEntity,
    ClimateEntityFeature,
    HVACAction,
    HVACMode,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import ATTR_TEMPERATURE, UnitOfTemperature
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.restore_state import RestoreEntity

from . import AudiRuntimeData
from .audi_entity import AudiEntity, entity_unique_id, should_create_entity
from .coordinator import AudiDataUpdateCoordinator
from .v3.climate import AudiV3Climate
from .v3.runtime import context_for

_ATTR_KEY = "climatisation_state"
# services.yaml bounds the temp_c field the same way.
_MIN_TEMP_C = 15
_MAX_TEMP_C = 30
_DEFAULT_TEMP_C = 21.0
# What the car reports when climatisation is doing nothing. Anything else is a
# running mode, so unknown modes read as on rather than silently as off.
_INACTIVE_STATES = frozenset({"off", "invalid", "unsupported", "error", ""})

_ACTIONS = {
    "heating": HVACAction.HEATING,
    "cooling": HVACAction.COOLING,
    "ventilation": HVACAction.FAN,
}


async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    runtime_data: AudiRuntimeData = config_entry.runtime_data
    entities = []
    for config_vehicle in runtime_data.account.config_vehicles:
        vehicle = config_vehicle.vehicle
        modern_v3 = (
            runtime_data.v3 is not None
            and context_for(vehicle, config_entry).auth == "auth0"
        )
        # A known positive capability can create control-only climate even
        # without a current status value. But an *omitted* capability in a
        # partial Audi list is not proof that an existing status entity must
        # disappear: preserve its registry ID/state, gate commands separately.
        create = should_create_entity(
            hass, "climate", "climatisation", vehicle, _ATTR_KEY
        )
        if modern_v3:
            # Capability aspects are optional and independent. Control-only
            # climate must be constructible without a current status reading,
            # including after the user explicitly opts into testing an UNKNOWN
            # capability. An explicit negative verdict still blocks control.
            entity = AudiV3Climate(
                runtime_data.coordinator, vehicle, runtime_data.v3
            )
            create = create or entity._may_control
        if not create:
            continue
        # Preserve the same unique ID and registry history. Other V2 climate
        # features remain untouched until individually migrated.
        if modern_v3:
            entities.append(entity)
        else:
            entities.append(AudiClimate(runtime_data.coordinator, vehicle))
    async_add_entities(entities)


class AudiClimate(AudiEntity, ClimateEntity, RestoreEntity):
    """Climatisation as a climate entity.

    Everything comes from the vehicle, including the target temperature, which
    the car reports in climatisationSettings. The locally held value is only a
    fallback for a car that does not report one, and for the moment between
    asking for a change and the car confirming it.
    """

    _backing_attr = _ATTR_KEY
    _attr_name = "Climatisation"
    _attr_hvac_modes = [HVACMode.OFF, HVACMode.HEAT_COOL]
    _attr_supported_features = (
        ClimateEntityFeature.TARGET_TEMPERATURE
        | ClimateEntityFeature.TURN_ON
        | ClimateEntityFeature.TURN_OFF
    )
    # HA 2026.11+: native temperature unit. Keep the legacy shorthand for
    # older HA releases; HA 2026.11 prefers the native attribute and does not
    # warn when both are provided.
    _attr_native_temperature_unit = UnitOfTemperature.CELSIUS
    _attr_temperature_unit = UnitOfTemperature.CELSIUS
    # The api_level 1 payload truncates the target to a whole number
    # (int(temp_c)), so a half-degree step would advertise a precision the car
    # never receives. api_level 0 keeps the fraction, but the step has to hold
    # for both.
    _attr_target_temperature_step = 1.0
    _attr_min_temp = _MIN_TEMP_C
    _attr_max_temp = _MAX_TEMP_C

    def __init__(
        self,
        coordinator: AudiDataUpdateCoordinator,
        vehicle: Any,
    ) -> None:
        super().__init__(coordinator, vehicle)
        self._attr_unique_id = entity_unique_id(vehicle, "climate", "climatisation")
        self._attr_native_target_temperature = _DEFAULT_TEMP_C

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        self._restore_target_temperature(await self.async_get_last_state())

    def _restore_target_temperature(self, last_state: Any) -> None:
        """Take the target back from the last recorded state, if there is one."""
        if last_state is None:
            return
        if (last := last_state.attributes.get(ATTR_TEMPERATURE)) is None:
            return
        # A recorded "unknown" must not wedge the entity on restart.
        with contextlib.suppress(TypeError, ValueError):
            self._attr_native_target_temperature = float(last)

    @property
    def _state(self) -> str:
        value = getattr(self._vehicle, _ATTR_KEY, None)
        return value.lower() if isinstance(value, str) else ""

    @property
    def _is_running(self) -> bool:
        return self._state not in _INACTIVE_STATES

    @property
    def native_target_temperature(self) -> float | None:
        """Prefer what the car reports over what we last asked for."""
        reported = getattr(self._vehicle, "climatisation_target_temperature", None)
        if isinstance(reported, (int, float)):
            return float(reported)
        return self._attr_native_target_temperature

    @property
    def target_temperature(self) -> float | None:
        """Compatibility for Home Assistant releases older than 2026.11."""
        return self.native_target_temperature

    @property
    def hvac_mode(self) -> HVACMode:
        return HVACMode.HEAT_COOL if self._is_running else HVACMode.OFF

    @property
    def hvac_action(self) -> HVACAction:
        if not self._is_running:
            return HVACAction.OFF
        # A running mode the map does not name is still running; IDLE would read
        # as "on but doing nothing", which is the wrong thing to claim.
        return _ACTIONS.get(self._state, HVACAction.HEATING)

    # current_temperature is deliberately absent: the car reports outdoor
    # temperature, not cabin temperature, and showing the outside reading as the
    # climate entity's current temperature would misstate what it measures.
    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        return {
            "climatisation_state": getattr(self._vehicle, _ATTR_KEY, None),
            "window_heating_enabled": getattr(
                self._vehicle, "climatisation_window_heating_enabled", None
            ),
            "climatisation_at_unlock": getattr(
                self._vehicle, "climatisation_at_unlock", None
            ),
            "remaining_climatisation_time": getattr(
                self._vehicle, "remaining_climatisation_time", None
            ),
        }

    async def async_set_hvac_mode(self, hvac_mode: HVACMode) -> None:
        if hvac_mode == HVACMode.OFF:
            await self.async_turn_off()
        else:
            await self.async_turn_on()

    async def async_turn_on(self, *, force_temperature: bool = False) -> None:
        connection = self.coordinator.account.connection
        # Some CARIAD cars accept start only with no body: use stored car
        # settings when explicitly enabled. Never silently override user temp.
        entry = getattr(self.coordinator, "config_entry", None)
        options = getattr(entry, "options", {}) if entry is not None else {}
        data = getattr(entry, "data", {}) if entry is not None else {}
        quick_start = bool(options.get("climate_quick_start", False))
        service = getattr(connection, "_audi_service", None)
        modern_api = (
            bool(getattr(service, "uses_auth0", False)) or data.get("api_level", 0) == 1
        )
        temperature = (
            None
            if quick_start and modern_api and not force_temperature
            else self.native_target_temperature
        )
        if not await connection.start_climate_control(
            self._vehicle.vin, temp_c=temperature
        ):
            raise HomeAssistantError(
                "Failed to start climatisation; see the log for details"
            )
        await self.coordinator.async_request_refresh()

    async def async_turn_off(self) -> None:
        connection = self.coordinator.account.connection
        if not await connection.set_vehicle_climatisation(self._vehicle.vin, False):
            raise HomeAssistantError(
                "Failed to stop climatisation; see the log for details"
            )
        await self.coordinator.async_request_refresh()

    async def async_set_temperature(self, **kwargs: Any) -> None:
        if (temperature := kwargs.get(ATTR_TEMPERATURE)) is None:
            return
        self._attr_native_target_temperature = float(temperature)
        self.async_write_ha_state()
        # Re-send only if it is already running, so setting a temperature while
        # off does not start the car climatising.
        if self._is_running:
            # An explicit temperature change must never be silently discarded
            # by the optional bodyless quick-start mode.
            await self.async_turn_on(force_temperature=True)


__all__ = ["AudiClimate", "async_setup_entry"]
