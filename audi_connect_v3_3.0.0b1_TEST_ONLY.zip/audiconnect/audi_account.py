from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from typing import Any

import homeassistant.helpers.config_validation as cv
import voluptuous as vol
from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.exceptions import ConfigEntryAuthFailed, HomeAssistantError
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .audi_connect_account import (
    AudiAuthError,
    AudiConnectAccount,
    AudiConnectObserver,
)
from .audi_models import VehicleData
from .vehicle_controls import engine_start_stop_supported
from .const import (
    CONF_ACTION,
    CONF_API_LEVEL,
    CONF_CLIMATE_AT_UNLOCK,
    CONF_CLIMATE_GLASS,
    CONF_CLIMATE_MODE,
    CONF_CLIMATE_SEAT_FL,
    CONF_CLIMATE_SEAT_FR,
    CONF_CLIMATE_SEAT_RL,
    CONF_CLIMATE_SEAT_RR,
    CONF_CLIMATE_TEMP_C,
    CONF_CLIMATE_TEMP_F,
    CONF_DEVICE_ID,
    CONF_DURATION,
    CONF_FILTER_VINS,
    CONF_PASSWORD,
    CONF_REFRESH_AFTER_ACTION,
    CONF_REFRESH_TOKEN,
    CONF_REGION,
    CONF_SPIN,
    CONF_CHARGE_MODE,
    CONF_PROFILE_ID,
    CONF_TARGET_SOC,
    CONF_UPDATE_SLEEP,
    CONF_USERNAME,
    DEFAULT_API_LEVEL,
    DOMAIN,
    REFRESH_VEHICLE_DATA_COMPLETED_EVENT,
    REFRESH_VEHICLE_DATA_FAILED_EVENT,
    UPDATE_SLEEP,
)

_LOGGER = logging.getLogger(__name__)


def _single_device_id(value: Any) -> str:
    """Accept the device either as a string or as a one-item list.

    An action called from a dashboard (e.g. a picture-elements action-button
    with `data: {device_id: ...}`) arrives with device_id as a list, which a
    plain cv.string rejects with "value should be a string" (#873). The actions
    target exactly one vehicle, so more than one device is still refused.
    """
    if isinstance(value, list):
        if len(value) != 1:
            raise vol.Invalid("exactly one device is required")
        value = value[0]
    return cv.string(value)


SERVICE_REFRESH_VEHICLE_DATA = "refresh_vehicle_data"
SERVICE_REFRESH_VEHICLE_DATA_SCHEMA = vol.Schema(
    {vol.Required(CONF_DEVICE_ID): _single_device_id}
)

SERVICE_EXECUTE_VEHICLE_ACTION = "execute_vehicle_action"
SERVICE_EXECUTE_VEHICLE_ACTION_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_DEVICE_ID): _single_device_id,
        vol.Required(CONF_ACTION): cv.string,
    }
)

SERVICE_START_CLIMATE_CONTROL = "start_climate_control"
SERVICE_START_CLIMATE_CONTROL_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_DEVICE_ID): _single_device_id,
        vol.Optional(CONF_CLIMATE_TEMP_F): cv.positive_int,
        vol.Optional(CONF_CLIMATE_TEMP_C): cv.positive_int,
        vol.Optional(CONF_CLIMATE_GLASS): cv.boolean,
        vol.Optional(CONF_CLIMATE_SEAT_FL): cv.boolean,
        vol.Optional(CONF_CLIMATE_SEAT_FR): cv.boolean,
        vol.Optional(CONF_CLIMATE_SEAT_RL): cv.boolean,
        vol.Optional(CONF_CLIMATE_SEAT_RR): cv.boolean,
        vol.Optional(CONF_CLIMATE_AT_UNLOCK): cv.boolean,
        vol.Optional(CONF_CLIMATE_MODE): cv.string,
    }
)

SERVICE_START_AUXILIARY_HEATING = "start_auxiliary_heating"
SERVICE_START_AUXILIARY_HEATING_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_DEVICE_ID): _single_device_id,
        vol.Optional(CONF_DURATION): cv.positive_int,
    }
)

SERVICE_SET_LOCATION_CHARGE_TARGET = "set_location_charge_target"
SERVICE_SET_LOCATION_CHARGE_TARGET_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_DEVICE_ID): _single_device_id,
        vol.Optional(CONF_PROFILE_ID): vol.All(
            cv.positive_int, vol.Range(min=1, max=10)
        ),
        vol.Required(CONF_TARGET_SOC): vol.All(
            cv.positive_int, vol.Range(min=20, max=100)
        ),
    }
)

SERVICE_SET_CHARGE_MODE = "set_charge_mode"
SERVICE_SET_CHARGE_MODE_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_DEVICE_ID): _single_device_id,
        vol.Required(CONF_CHARGE_MODE): vol.In(["manual", "timer"]),
    }
)

SERVICE_SET_TARGET_SOC = "set_target_soc"
SERVICE_SET_TARGET_SOC_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_DEVICE_ID): _single_device_id,
        vol.Required(CONF_TARGET_SOC): vol.All(
            cv.positive_int, vol.Range(min=20, max=100)
        ),
    }
)

SERVICE_START_ENGINE = "start_engine"
SERVICE_START_ENGINE_SCHEMA = vol.Schema(
    {vol.Required(CONF_DEVICE_ID): _single_device_id}
)

SERVICE_STOP_ENGINE = "stop_engine"
SERVICE_STOP_ENGINE_SCHEMA = vol.Schema(
    {vol.Required(CONF_DEVICE_ID): _single_device_id}
)

SERVICE_REFRESH_CLOUD_DATA = "refresh_cloud_data"


class AudiAccount(AudiConnectObserver):
    """Account wrapper that owns the Audi API client and discovered vehicles."""

    def __init__(self, hass: HomeAssistant, config_entry: Any) -> None:
        self.hass = hass
        self.config_entry = config_entry
        self.config_vehicles: list[VehicleData] = []
        self._known_vehicle_vins: set[str] = set()
        self._refresh_callback: Callable[[], Any] | None = None

        session = async_get_clientsession(self.hass)
        excluded_vins = [
            vin.strip().lower()
            for vin in self.config_entry.options.get(
                CONF_FILTER_VINS, self.config_entry.data.get(CONF_FILTER_VINS, "")
            ).split(",")
            if vin.strip()
        ]

        self.connection = AudiConnectAccount(
            session=session,
            country=self.config_entry.data.get(CONF_REGION),
            spin=self.config_entry.data.get(CONF_SPIN),
            api_level=self.config_entry.data.get(CONF_API_LEVEL, DEFAULT_API_LEVEL),
            excluded_vins=excluded_vins,
            refresh_token=self.config_entry.data.get(CONF_REFRESH_TOKEN),
            username=self.config_entry.data.get(CONF_USERNAME),
            password=self.config_entry.data.get(CONF_PASSWORD),
        )
        self.connection.add_observer(self)
        self.connection.set_refresh_token_listener(self._persist_refresh_token)

    def set_refresh_callback(self, callback: Callable[[], Any]) -> None:
        self._refresh_callback = callback

    def _persist_refresh_token(self, refresh_token: str) -> None:
        """Persist a rotated IDK refresh token back to the config entry."""
        if self.config_entry.data.get(CONF_REFRESH_TOKEN) == refresh_token:
            return
        self.hass.config_entries.async_update_entry(
            self.config_entry,
            data={**self.config_entry.data, CONF_REFRESH_TOKEN: refresh_token},
        )

    def _build_vehicle_data(self, vehicle: Any) -> VehicleData:
        cfg_vehicle = VehicleData(self.config_entry)
        cfg_vehicle.vehicle = vehicle
        return cfg_vehicle

    async def async_refresh_data(self) -> list[VehicleData]:
        """Refresh cloud data and update discovered vehicles."""
        _LOGGER.debug("Starting refresh cloud data...")
        try:
            updated = await self.connection.update(None)
        except AudiAuthError as err:
            raise ConfigEntryAuthFailed(str(err)) from err
        if not updated:
            _LOGGER.warning("Failed refresh cloud data")
            raise RuntimeError("Failed refresh cloud data")

        known = {
            vehicle.vehicle.vin.lower(): vehicle
            for vehicle in self.config_vehicles
            if vehicle.vehicle and vehicle.vehicle.vin
        }
        for vehicle in self.connection.vehicles:
            vin = vehicle.vin.lower()
            if vin in known:
                continue
            self._known_vehicle_vins.add(vin)
            self.config_vehicles.append(self._build_vehicle_data(vehicle))

        _LOGGER.debug("Successfully refreshed cloud data")
        return self.config_vehicles

    async def execute_vehicle_action(self, vin: str, service: ServiceCall) -> None:
        """Execute a vehicle action by VIN."""
        vin = vin.lower()
        action = service.data.get(CONF_ACTION).lower()

        if action == "lock":
            result = await self.connection.set_vehicle_lock(vin, True)
            self._raise_on_failed_command(result, action)
        elif action == "unlock":
            result = await self.connection.set_vehicle_lock(vin, False)
            self._raise_on_failed_command(result, action)
        elif action == "start_climatisation":
            # Existing HA scripts/automations still call this action; route
            # them to the supported start with car-stored settings instead
            # of the permanently disabled legacy start command.
            result = await self.connection.start_climate_control(vin)
            self._raise_on_failed_command(result, action)
        elif action == "stop_climatisation":
            result = await self.connection.set_vehicle_climatisation(vin, False)
            self._raise_on_failed_command(result, action)
        elif action == "start_charger":
            await self._charger_action(vin, action, True, False)
        elif action == "start_timed_charger":
            await self._charger_action(vin, action, True, True)
        elif action == "stop_charger":
            await self._charger_action(vin, action, False, False)
        elif action == "start_preheater":
            _LOGGER.warning(
                'The "Start Preheater (Legacy)" action is deprecated and will be removed in a future release. '
                'Please use the "Start Auxiliary Heating" service instead.'
            )
            await self.connection.set_vehicle_pre_heater(vin, True)
        elif action == "stop_preheater":
            await self.connection.set_vehicle_pre_heater(vin, False)
        elif action == "start_window_heating":
            await self.connection.set_vehicle_window_heating(vin, True)
        elif action == "stop_window_heating":
            await self.connection.set_vehicle_window_heating(vin, False)
        else:
            raise HomeAssistantError(f"Unknown Audi vehicle action: {action}")

    @staticmethod
    def _raise_on_failed_command(result: Any, action: str) -> None:
        """Do not return HA service success when the connection returned False."""
        if result is False:
            raise HomeAssistantError(
                f"Audi Connect {action.replace('_', ' ')} failed. "
                "Inspect the integration log for the underlying API error."
            )

    async def _charger_action(
        self, vin: str, action: str, start: bool, timer: bool
    ) -> None:
        """Run a charger action and raise when it did not take.

        set_battery_charger logs its exceptions and returns None rather than
        propagating, so a charger command that never reached the car still
        answered 200 to whoever called the service. Anything driving a Start or
        Stop button needs to be able to tell the difference.
        """
        if not await self.connection.set_battery_charger(vin, start, timer):
            raise HomeAssistantError(
                f"Audi Connect could not {action.replace('_', ' ')} for {vin}. "
                "See the log for the underlying error."
            )

    async def start_climate_control(self, vin: str, service: ServiceCall) -> None:
        """Start climate control for a vehicle by VIN."""
        # Pass the fields through as supplied, without substituting defaults, so
        # the service layer can tell "the caller wants everything left alone"
        # apart from "the caller explicitly asked for all of it off".
        result = await self.connection.start_climate_control(
            vin.lower(),
            service.data.get(CONF_CLIMATE_TEMP_F),
            service.data.get(CONF_CLIMATE_TEMP_C),
            service.data.get(CONF_CLIMATE_GLASS),
            service.data.get(CONF_CLIMATE_SEAT_FL),
            service.data.get(CONF_CLIMATE_SEAT_FR),
            service.data.get(CONF_CLIMATE_SEAT_RL),
            service.data.get(CONF_CLIMATE_SEAT_RR),
            service.data.get(CONF_CLIMATE_AT_UNLOCK),
            service.data.get(CONF_CLIMATE_MODE),
        )
        self._raise_on_failed_command(result, "start_climate_control")

    async def start_auxiliary_heating(self, vin: str, service: ServiceCall) -> None:
        """Start auxiliary heating for a vehicle by VIN."""
        await self.connection.set_vehicle_pre_heater(
            vin=vin.lower(),
            activate=True,
            duration=service.data.get(CONF_DURATION),
        )

    async def set_location_charge_target(self, vin: str, service: ServiceCall) -> None:
        """Set a location profile's target SoC, the value that governs charging
        at that place. Omit profile_id to target where the car is parked now."""
        if not await self.connection.set_location_charge_target(
            vin.lower(),
            service.data.get(CONF_PROFILE_ID),
            service.data.get(CONF_TARGET_SOC),
        ):
            raise HomeAssistantError(
                f"Audi Connect could not set the location charge target for {vin}. "
                "See the log for the underlying error."
            )

    async def set_charge_mode(self, vin: str, service: ServiceCall) -> None:
        """Set which mode the car charges in, without starting or stopping one."""
        result = await self.connection.set_charge_mode(
            vin.lower(),
            service.data.get(CONF_CHARGE_MODE),
        )
        self._raise_on_failed_command(result, "set_charge_mode")

    async def set_target_soc(self, vin: str, service: ServiceCall) -> None:
        """Set target state of charge for a vehicle by VIN."""
        result = await self.connection.set_target_state_of_charge(
            vin.lower(),
            service.data.get(CONF_TARGET_SOC),
        )
        self._raise_on_failed_command(result, "set_target_soc")

    def _require_remote_engine_support(self, vin: str) -> None:
        """Check direct-service calls as well as buttons; never infer capability."""
        for config_vehicle in self.config_vehicles:
            vehicle = config_vehicle.vehicle
            if (
                vehicle is not None
                and vehicle.vin.lower() == vin.lower()
                and engine_start_stop_supported(vehicle)
            ):
                return
        raise HomeAssistantError(
            "Remote engine start/stop is not verified for this vehicle. "
            "Only a vehicle-reported remote-start capability can enable it; "
            "do not substitute this for electric cabin preconditioning."
        )

    async def start_engine(self, vin: str) -> None:
        """Start only when the vehicle explicitly reports remote-start support."""
        self._require_remote_engine_support(vin)
        if not await self.connection.start_engine(vin.lower()):
            raise HomeAssistantError("Audi Connect could not start the engine.")

    async def stop_engine(self, vin: str) -> None:
        """Stop only when the vehicle explicitly reports remote-start support."""
        self._require_remote_engine_support(vin)
        if not await self.connection.stop_engine(vin.lower()):
            raise HomeAssistantError("Audi Connect could not stop the engine.")

    async def handle_notification(self, vin: str, action: str) -> None:
        if self.config_entry.options.get(CONF_REFRESH_AFTER_ACTION, False):
            await self._refresh_vehicle_data(vin)
        else:
            update_sleep = self.config_entry.options.get(
                CONF_UPDATE_SLEEP, UPDATE_SLEEP
            )
            _LOGGER.debug("Sleeping %s seconds before cloud data refresh", update_sleep)
            await asyncio.sleep(update_sleep)
            if self._refresh_callback:
                await self._refresh_callback()

    async def refresh_vehicle_data(self, vin: str) -> None:
        """Refresh data for a specific vehicle by VIN."""
        await self._refresh_vehicle_data(vin.lower())

    async def _refresh_vehicle_data(self, vin: str) -> None:
        redacted_vin = "*" * (len(vin) - 4) + vin[-4:]
        result = await self.connection.refresh_vehicle_data(vin)

        if result is True:
            self.hass.bus.async_fire(
                f"{DOMAIN}_{REFRESH_VEHICLE_DATA_COMPLETED_EVENT}",
                {"vin": redacted_vin},
            )
        elif result != "disabled":
            self.hass.bus.async_fire(
                f"{DOMAIN}_{REFRESH_VEHICLE_DATA_FAILED_EVENT}", {"vin": redacted_vin}
            )

        update_sleep = self.config_entry.options.get(CONF_UPDATE_SLEEP, UPDATE_SLEEP)
        _LOGGER.debug("Sleeping %s seconds before cloud data refresh", update_sleep)
        await asyncio.sleep(update_sleep)
        if self._refresh_callback:
            await self._refresh_callback()


__all__ = [
    "SERVICE_EXECUTE_VEHICLE_ACTION",
    "SERVICE_EXECUTE_VEHICLE_ACTION_SCHEMA",
    "SERVICE_REFRESH_CLOUD_DATA",
    "SERVICE_REFRESH_VEHICLE_DATA",
    "SERVICE_REFRESH_VEHICLE_DATA_SCHEMA",
    "SERVICE_SET_CHARGE_MODE",
    "SERVICE_SET_LOCATION_CHARGE_TARGET",
    "SERVICE_SET_LOCATION_CHARGE_TARGET_SCHEMA",
    "SERVICE_SET_CHARGE_MODE_SCHEMA",
    "SERVICE_SET_TARGET_SOC",
    "SERVICE_SET_TARGET_SOC_SCHEMA",
    "SERVICE_START_AUXILIARY_HEATING",
    "SERVICE_START_AUXILIARY_HEATING_SCHEMA",
    "SERVICE_START_CLIMATE_CONTROL",
    "SERVICE_START_CLIMATE_CONTROL_SCHEMA",
    "SERVICE_START_ENGINE",
    "SERVICE_START_ENGINE_SCHEMA",
    "SERVICE_STOP_ENGINE",
    "SERVICE_STOP_ENGINE_SCHEMA",
    "AudiAccount",
]
