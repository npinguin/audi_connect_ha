from __future__ import annotations

import logging
from typing import Any

from .util import get_attr

_LOGGER = logging.getLogger(__name__)


class VehicleData:
    def __init__(self, config_entry: Any) -> None:
        self.config_entry = config_entry
        self.vehicle: Vehicle | None = None


class CurrentVehicleDataResponse:
    def __init__(self, data: dict[str, Any]) -> None:
        data = data["CurrentVehicleDataResponse"]
        self.request_id: str = data["requestId"]
        self.vin: str = data["vin"]


def _count_error_objects(data: Any) -> int:
    """Count the ``error`` objects anywhere in a selectivestatus payload.

    On a CARIAD outage the API answers 200 but drops an ``error`` object where the
    ``value`` should be, for every job. Counting them is how we tell a transient
    outage from a car that just doesn't have a feature, since both otherwise parse
    to nothing. See audiconnect/audi_connect_ha#793.
    """
    if isinstance(data, dict):
        here = 1 if "error" in data else 0
        return here + sum(_count_error_objects(v) for v in data.values())
    if isinstance(data, list):
        return sum(_count_error_objects(v) for v in data)
    return 0


class VehicleDataResponse:
    OLDAPI_MAPPING = {
        "frontRightLock": "LOCK_STATE_RIGHT_FRONT_DOOR",
        "frontRightOpen": "OPEN_STATE_RIGHT_FRONT_DOOR",
        "frontLeftLock": "LOCK_STATE_LEFT_FRONT_DOOR",
        "frontLeftOpen": "OPEN_STATE_LEFT_FRONT_DOOR",
        "rearRightLock": "LOCK_STATE_RIGHT_REAR_DOOR",
        "rearRightOpen": "OPEN_STATE_RIGHT_REAR_DOOR",
        "rearLeftLock": "LOCK_STATE_LEFT_REAR_DOOR",
        "rearLeftOpen": "OPEN_STATE_LEFT_REAR_DOOR",
        "trunkLock": "LOCK_STATE_TRUNK_LID",
        "trunkOpen": "OPEN_STATE_TRUNK_LID",
        "bonnetLock": "LOCK_STATE_HOOD",
        "bonnetOpen": "OPEN_STATE_HOOD",
        "sunRoofWindow": "STATE_SUN_ROOF_MOTOR_COVER",
        "frontLeftWindow": "STATE_LEFT_FRONT_WINDOW",
        "frontRightWindow": "STATE_RIGHT_FRONT_WINDOW",
        "rearLeftWindow": "STATE_LEFT_REAR_WINDOW",
        "rearRightWindow": "STATE_RIGHT_REAR_WINDOW",
        "roofCoverWindow": "STATE_ROOF_COVER_WINDOW",
    }

    @property
    def all_jobs_errored(self) -> bool:
        """True when the payload had error objects and nothing usable came out of
        it, so a transient CARIAD outage, not a car that's missing features (#793)."""
        return self.error_count > 0 and not self.data_fields and not self.states

    def __init__(self, data: dict[str, Any]) -> None:
        self.data_fields: list[Field] = []
        self.states: list[dict[str, Any]] = []
        # #793: count the error objects up front, so an all-error outage (200 but
        # every job errored) can be told apart from a car that lacks a feature.
        self.error_count: int = _count_error_objects(data)

        self._tryAppendFieldWithTs(
            data, "TOTAL_RANGE", ["fuelStatus", "rangeStatus", "value", "totalRange_km"]
        )
        self._tryAppendFieldWithTs(
            data,
            "TANK_LEVEL_IN_PERCENTAGE",
            ["measurements", "fuelLevelStatus", "value", "currentFuelLevel_pct"],
        )
        self._tryAppendFieldWithTs(
            data,
            "UTC_TIME_AND_KILOMETER_STATUS",
            ["measurements", "odometerStatus", "value", "odometer"],
        )
        self._tryAppendFieldWithTs(
            data,
            "MAINTENANCE_INTERVAL_TIME_TO_INSPECTION",
            [
                "vehicleHealthInspection",
                "maintenanceStatus",
                "value",
                "inspectionDue_days",
            ],
        )
        self._tryAppendFieldWithTs(
            data,
            "MAINTENANCE_INTERVAL_DISTANCE_TO_INSPECTION",
            [
                "vehicleHealthInspection",
                "maintenanceStatus",
                "value",
                "inspectionDue_km",
            ],
        )

        self._tryAppendFieldWithTs(
            data,
            "MAINTENANCE_INTERVAL_TIME_TO_OIL_CHANGE",
            [
                "vehicleHealthInspection",
                "maintenanceStatus",
                "value",
                "oilServiceDue_days",
            ],
        )
        self._tryAppendFieldWithTs(
            data,
            "MAINTENANCE_INTERVAL_DISTANCE_TO_OIL_CHANGE",
            [
                "vehicleHealthInspection",
                "maintenanceStatus",
                "value",
                "oilServiceDue_km",
            ],
        )

        self._tryAppendFieldWithTs(
            data,
            "OIL_LEVEL_DIPSTICKS_PERCENTAGE",
            ["oilLevel", "oilLevelStatus", "value", "value"],
        )
        self._tryAppendFieldWithTs(
            data,
            "ADBLUE_RANGE",
            ["measurements", "rangeStatus", "value", "adBlueRange"],
        )

        self._tryAppendFieldWithTs(
            data, "LIGHT_STATUS", ["vehicleLights", "lightsStatus", "value", "lights"]
        )

        self.appendWindowState(data)
        self.appendDoorState(data)

        # The car's own verdict on the whole vehicle. The per-door derivation
        # above needs all four doors and a coupé has two, which is how a locked
        # A5 read as unlocked (#861). This field was in every poll all along.
        self._tryAppendStateWithTs(
            data,
            "doorLockStatus",
            -1,
            ["access", "accessStatus", "value", "doorLockStatus"],
        )

        self._tryAppendStateWithTs(
            data, "carType", -1, ["fuelStatus", "rangeStatus", "value", "carType"]
        )

        self._tryAppendStateWithTs(
            data,
            "engineTypeFirstEngine",
            -2,
            ["fuelStatus", "rangeStatus", "value", "primaryEngine", "type"],
        )
        self._tryAppendStateWithTs(
            data,
            "primaryEngineRange",
            -2,
            [
                "fuelStatus",
                "rangeStatus",
                "value",
                "primaryEngine",
                "remainingRange_km",
            ],
        )
        self._tryAppendStateWithTs(
            data,
            "primaryEngineRangePercent",
            -2,
            ["fuelStatus", "rangeStatus", "value", "primaryEngine", "currentSOC_pct"],
        )
        self._tryAppendStateWithTs(
            data,
            "engineTypeSecondEngine",
            -2,
            ["fuelStatus", "rangeStatus", "value", "secondaryEngine", "type"],
        )
        self._tryAppendStateWithTs(
            data,
            "secondaryEngineRange",
            -2,
            [
                "fuelStatus",
                "rangeStatus",
                "value",
                "secondaryEngine",
                "remainingRange_km",
            ],
        )
        self._tryAppendStateWithTs(
            data,
            "secondaryEngineRangePercent",
            -2,
            ["fuelStatus", "rangeStatus", "value", "secondaryEngine", "currentSOC_pct"],
        )
        self._tryAppendStateWithTs(
            data,
            "hybridRange",
            -1,
            ["fuelStatus", "rangeStatus", "value", "totalRange_km"],
        )
        self._tryAppendStateWithTs(
            data,
            "stateOfCharge",
            -1,
            ["charging", "batteryStatus", "value", "currentSOC_pct"],
        )
        self._tryAppendStateWithTs(
            data,
            "chargingState",
            -1,
            ["charging", "chargingStatus", "value", "chargingState"],
        )
        self._tryAppendStateWithTs(
            data,
            "chargeMode",
            -1,
            ["charging", "chargingStatus", "value", "chargeMode"],
        )
        # The mode of the charge in progress, above, is not the mode the car is
        # SET to: that is preferredChargeMode, which is what set_charge_mode
        # writes. They agree most of the time, which is what makes reading the
        # wrong one hard to notice.
        #
        # The chargeMode block carries no carCapturedTimestamp of its own, so
        # _tryAppendStateWithTs drops it silently. Borrow the charging status
        # timestamp, which is the freshness marker for the same fetch.
        charge_mode_ts = self._getFromJson(
            data, ["charging", "chargingStatus", "value", "carCapturedTimestamp"]
        )
        self._appendState(
            "preferredChargeMode",
            self._getFromJson(
                data, ["charging", "chargeMode", "value", "preferredChargeMode"]
            ),
            charge_mode_ts,
        )
        available_modes = self._getFromJson(
            data, ["charging", "chargeMode", "value", "availableChargeModes"]
        )
        if available_modes is not None:
            # An empty list is a real answer ("the car lists none"), and
            # _appendState would drop it as falsy.
            self.states.append(
                {
                    "name": "availableChargeModes",
                    "value": available_modes,
                    "measure_time": charge_mode_ts,
                }
            )
        self._tryAppendStateWithTs(
            data,
            "chargingPower",
            -1,
            ["charging", "chargingStatus", "value", "chargePower_kW"],
        )
        self._tryAppendStateWithTs(
            data,
            "actualChargeRate",
            -1,
            ["charging", "chargingStatus", "value", "chargeRate_kmph"],
        )
        self._tryAppendStateWithTs(
            data,
            "chargeType",
            -1,
            ["charging", "chargingStatus", "value", "chargeType"],
        )
        self._tryAppendStateWithTs(
            data,
            "targetstateOfCharge",
            -1,
            ["charging", "chargingSettings", "value", "targetSOC_pct"],
        )
        self._tryAppendStateWithTs(
            data,
            "plugState",
            -1,
            ["charging", "plugStatus", "value", "plugConnectionState"],
        )
        self._tryAppendStateWithTs(
            data,
            "remainingChargingTime",
            -1,
            [
                "charging",
                "chargingStatus",
                "value",
                "remainingChargingTimeToComplete_min",
            ],
        )
        self._tryAppendStateWithTs(
            data,
            "plugLockState",
            -1,
            ["charging", "plugStatus", "value", "plugLockState"],
        )
        self._tryAppendStateWithTs(
            data,
            "externalPower",
            -1,
            ["charging", "plugStatus", "value", "externalPower"],
        )
        self._tryAppendStateWithTs(
            data,
            "plugledColor",
            -1,
            ["charging", "plugStatus", "value", "ledColor"],
        )
        self._tryAppendStateWithTs(
            data,
            "climatisationState",
            -1,
            ["climatisation", "auxiliaryHeatingStatus", "value", "climatisationState"],
        )
        # 2024 Q4 updated data structure for climate data
        self._tryAppendStateWithTs(
            data,
            "climatisationState",
            -1,
            ["climatisation", "climatisationStatus", "value", "climatisationState"],
        )
        # The whole climatisationSettings block was fetched and dropped. The
        # target temperature in particular is reported by the car, so it does
        # not have to be held locally and guessed at.
        for name, key in (
            ("climatisationTargetTemperatureC", "targetTemperature_C"),
            ("climatisationTargetTemperatureF", "targetTemperature_F"),
            ("climatisationWindowHeatingEnabled", "windowHeatingEnabled"),
            ("climatisationAtUnlock", "climatizationAtUnlock"),
            ("climatisationWithoutExternalPower", "climatisationWithoutExternalPower"),
            ("climatisationZoneFrontLeft", "zoneFrontLeftEnabled"),
            ("climatisationZoneFrontRight", "zoneFrontRightEnabled"),
            ("climatisationZoneRearLeft", "zoneRearLeftEnabled"),
            ("climatisationZoneRearRight", "zoneRearRightEnabled"),
        ):
            self._tryAppendStateWithTs(
                data, name, -1, ["climatisation", "climatisationSettings", "value", key]
            )
        self._tryAppendStateWithTs(
            data,
            "remainingClimatisationTime",
            -1,
            [
                "climatisation",
                "climatisationStatus",
                "value",
                "remainingClimatisationTime_min",
            ],
        )
        # Additional modern CARIAD fields interpreted by CarConnectivity:
        # keep numeric charging limits distinct from qualitative settings.
        for name, key in (
            ("chargingCurrentLimitA", "maxChargeCurrentAC_A"),
            ("chargingCurrentLimitMode", "maxChargeCurrentAC"),
            ("chargingPlugAutoUnlock", "autoUnlockPlugWhenChargedAC"),
        ):
            self._tryAppendStateWithTs(
                data, name, -1, ["charging", "chargingSettings", "value", key]
            )
        # Audi reports online/active at the vehicle, not at the cloud gateway.
        # This readiness block may have no capture time: never assign an
        # invented timestamp or claim every other status is freshly measured.
        connection = self._getFromJson(
            data, ["readiness", "readinessStatus", "value", "connectionState"]
        )
        if isinstance(connection, dict):
            for name, source in (
                ("vehicleReportedOnline", "isOnline"),
                ("vehicleReportedActive", "isActive"),
            ):
                if isinstance(connection.get(source), bool):
                    self.states.append(
                        {
                            "name": name,
                            "value": connection[source],
                            "measure_time": None,
                        }
                    )

        self._parseChargingProfiles(data)
        self._parseChargingTimers(data)
        self._parseClimatisationTimers(data)
        self._parseUserCapabilities(data)

    def _appendState(self, name: str, value: Any, ts: Any) -> None:
        """Append a derived state. Used by the charging-profile and timer parsers,
        which pick values out of a list rather than a fixed path, so they can't go
        through _tryAppendStateWithTs."""
        if value is None or not ts:
            return
        self.states.append({"name": name, "value": value, "measure_time": ts})

    def _parseUserCapabilities(self, data: dict[str, Any]) -> None:
        """Record what the car says it can do, as distinct from what this poll
        happened to contain.

        Entity creation is otherwise gated on a field being present right now,
        so a partial or rate-limited poll deletes controls until the next
        reload. The capability list is stable across polls and is the thing that
        should decide whether an entity exists at all.

        Job-level, not field-level: it answers "does this car do charging",
        never "does it report targetSOC_pct".
        """
        value = self._getFromJson(
            data, ["userCapabilities", "capabilitiesStatus", "value"]
        )
        if not isinstance(value, list):
            return

        ids = []
        impaired = []
        for entry in value:
            if not isinstance(entry, dict):
                continue
            cap_id = entry.get("id")
            if not isinstance(cap_id, str) or not cap_id:
                continue
            ids.append(cap_id)
            # A listed capability can still be reporting an error, so it is not
            # the same as a working one.
            if entry.get("status"):
                impaired.append(cap_id)

        if not ids:
            return

        # No timestamp accompanies this block, and it does not need one: it is a
        # statement about the vehicle rather than a reading from it.
        self.states.append(
            {"name": "userCapabilities", "value": sorted(ids), "measure_time": None}
        )
        if impaired:
            self.states.append(
                {
                    "name": "userCapabilitiesImpaired",
                    "value": sorted(impaired),
                    "measure_time": None,
                }
            )

    def _parseChargingProfiles(self, data: dict[str, Any]) -> None:
        """Parse the location charging profiles.

        The profile matching the car's current position is what actually governs a
        charge; the global charging/settings targetSOC_pct does not. A car sitting
        at a location whose profile says 60% will stop there while the global
        setting still reads 70% (upstream audiconnect#722, still open as of 2.3.1).
        """
        value = self._getFromJson(
            data, ["chargingProfiles", "chargingProfilesStatus", "value"]
        )
        if not isinstance(value, dict):
            return

        ts = value.get("carCapturedTimestamp")
        profiles = value.get("profiles")
        if not isinstance(profiles, list):
            profiles = []

        active_id = value.get("vehiclePositionedInProfileID")
        active = next(
            (p for p in profiles if isinstance(p, dict) and p.get("id") == active_id),
            None,
        )

        # position carries the owner's home coordinates, so it is deliberately not
        # copied into the attribute summary that ends up in the recorder database.
        summary = [
            {
                "id": p.get("id"),
                "name": p.get("name"),
                "targetSOC_pct": p.get("targetSOC_pct"),
                "minSOC_pct": p.get("minSOC_pct"),
                "minSOC_enabled": p.get("minSOC_enabled"),
                "preferredChargingTimes": p.get("preferredChargingTimes"),
            }
            for p in profiles
            if isinstance(p, dict)
        ]

        self._appendState("chargingProfiles", summary, ts)
        self._appendState("chargingProfileCount", len(summary), ts)
        self._appendState("activeChargingProfileId", active_id, ts)

        if active is None:
            return

        self._appendState("activeChargingProfileName", active.get("name"), ts)
        self._appendState(
            "activeChargingProfileTargetSoc", active.get("targetSOC_pct"), ts
        )
        self._appendState("activeChargingProfileMinSoc", active.get("minSOC_pct"), ts)

        # The preferred charging window is the per-location time band; this is the
        # field a smart-tariff scheduler writes when it moves a charge.
        times = active.get("preferredChargingTimes")
        if isinstance(times, list) and times:
            window = next(
                (t for t in times if isinstance(t, dict) and t.get("enabled")),
                times[0] if isinstance(times[0], dict) else None,
            )
            if window is not None:
                self._appendState(
                    "preferredChargingTimeStart", window.get("startTimeLocal"), ts
                )
                self._appendState(
                    "preferredChargingTimeEnd", window.get("endTimeLocal"), ts
                )
                # bool is appended explicitly: _appendState drops None, and False
                # is a meaningful value here.
                enabled = window.get("enabled")
                if enabled is not None:
                    self._appendState("preferredChargingTimeEnabled", bool(enabled), ts)

    def _parseChargingTimers(self, data: dict[str, Any]) -> None:
        """Parse the departure/charging timers.

        Note these are the *chargingTimers* job. departureTimers/departureProfiles
        are requested by get_stored_vehicle_data but are not returned for every
        model (a Q8 e-tron returns neither), so nothing here may depend on them.
        """
        value = self._getFromJson(
            data, ["chargingTimers", "chargingTimersStatus", "value"]
        )
        if not isinstance(value, dict):
            return

        ts = value.get("carCapturedTimestamp")
        timers = value.get("timers")
        if not isinstance(timers, list):
            return

        summary = []
        for t in timers:
            if not isinstance(t, dict):
                continue
            recurring = t.get("recurringTimer")
            entry = {
                "id": t.get("id"),
                "enabled": t.get("enabled"),
                "climatisation": t.get("climatisation"),
            }
            if isinstance(recurring, dict):
                entry["departureTimeLocal"] = recurring.get("departureTimeLocal")
                entry["repetitionDays"] = recurring.get("repetitionDays")
            summary.append(entry)

        self._appendState("chargingTimers", summary, ts)
        self._appendState(
            "chargingTimerEnabledCount",
            sum(1 for t in summary if t.get("enabled")),
            ts,
        )

        active = [t for t in summary if t.get("enabled")]
        if active:
            self._appendState(
                "nextChargingTimerDeparture", active[0].get("departureTimeLocal"), ts
            )

    def _parseClimatisationTimers(self, data: dict[str, Any]) -> None:
        """Expose the Q8's real climate timers without pretending local time is UTC.

        Audi returns each timer's startDateTimeLocal in the car's local clock.
        Until an explicit timezone is supplied, it must remain a string, not
        a HA timestamp sensor with a guessed offset. Keep the state bounded and
        strip every field except the small, documented timer subset.
        """
        block = self._getFromJson(
            data, ["climatisationTimers", "climatisationTimersStatus", "value"]
        )
        if not isinstance(block, dict):
            return
        ts = block.get("carCapturedTimestamp")
        timers = block.get("timers")
        if not isinstance(timers, list):
            return
        entries: list[dict[str, Any]] = []
        for timer in timers[:12]:
            if not isinstance(timer, dict):
                continue
            record: dict[str, Any] = {}
            if isinstance(timer.get("id"), (int, str)):
                record["id"] = timer["id"]
            if isinstance(timer.get("enabled"), bool):
                record["enabled"] = timer["enabled"]
            single = timer.get("singleTimer")
            if isinstance(single, dict):
                local_start = single.get("startDateTimeLocal")
                if isinstance(local_start, str) and len(local_start) <= 40:
                    record["startDateTimeLocal"] = local_start
            recurring = timer.get("recurringTimer")
            if isinstance(recurring, dict):
                local_time = recurring.get("departureTimeLocal")
                if isinstance(local_time, str) and len(local_time) <= 40:
                    record["departureTimeLocal"] = local_time
                days = recurring.get("repetitionDays")
                if isinstance(days, list):
                    record["repetitionDays"] = [
                        day for day in days[:7] if isinstance(day, (str, int))
                    ]
            entries.append(record)

        self._appendState("climatisationTimers", entries, ts)
        self._appendState("climatisationTimerCount", len(entries), ts)
        self._appendState(
            "climatisationTimerEnabledCount",
            sum(item.get("enabled") is True for item in entries),
            ts,
        )
        enabled_starts = sorted(
            item["startDateTimeLocal"]
            for item in entries
            if item.get("enabled") is True and "startDateTimeLocal" in item
        )
        if enabled_starts:
            self._appendState("nextClimatisationTimerLocal", enabled_starts[0], ts)

    def _tryAppendStateWithTs(
        self, json: dict[str, Any], name: str, tsoff: int, loc: list[str]
    ) -> None:
        _LOGGER.debug(
            "TRY APPEND STATE: Searching for '%s' at location=%s, tsoff=%s",
            name,
            loc,
            tsoff,
        )

        ts = None
        val = self._getFromJson(json, loc)
        # _LOGGER.debug("Initial value retrieved for '%s': %s", name, val)

        if val is not None:
            loc[tsoff:] = ["carCapturedTimestamp"]
            # _LOGGER.debug("Updated loc for timestamp retrieval: %s", loc)
            ts = self._getFromJson(json, loc)
            # _LOGGER.debug("Timestamp retrieved for '%s': %s", name, ts)

        if val is not None and ts:
            self.states.append({"name": name, "value": val, "measure_time": ts})
            _LOGGER.debug(
                "TRY APPEND STATE: Found '%s' with value=%s, tsoff=%s, loc=%s, ts=%s",
                name,
                val,
                tsoff,
                loc,
                ts,
            )
        else:
            if val is None:
                _LOGGER.debug(
                    "TRY APPEND STATE: Value for '%s' is None; not appending state.",
                    name,
                )
            elif not ts:
                _LOGGER.debug(
                    "TRY APPEND STATE: Timestamp for '%s' is None or missing; not appending state.",
                    name,
                )

    def _tryAppendFieldWithTs(
        self, json: dict[str, Any], textId: str, loc: list[str]
    ) -> None:
        _LOGGER.debug(
            "TRY APPEND FIELD: Searching for '%s' at location=%s",
            textId,
            loc,
        )

        ts = None
        val = self._getFromJson(json, loc)
        # _LOGGER.debug("Initial value retrieved for '%s': %s", textId, val)

        if val is not None:
            loc[-1:] = ["carCapturedTimestamp"]
            # _LOGGER.debug("Updated loc for timestamp retrieval: %s", loc)
            ts = self._getFromJson(json, loc)
            # _LOGGER.debug("Timestamp retrieved for '%s': %s", textId, ts)

        if val is not None and ts:
            self.data_fields.append(
                Field(
                    {
                        "textId": textId,
                        "value": val,
                        "tsCarCaptured": ts,
                    }
                )
            )
            _LOGGER.debug(
                "TRY APPEND FIELD: Found '%s' with value=%s, loc=%s, ts=%s",
                textId,
                val,
                loc,
                ts,
            )
        else:
            if val is None:
                _LOGGER.debug(
                    "TRY APPEND FIELD: Value for '%s' is None or missing; not appending field.",
                    textId,
                )
            elif not ts:
                _LOGGER.debug(
                    "TRY APPEND FIELD: Timestamp for '%s' is None or missing; not appending field.",
                    textId,
                )

    def _getFromJson(self, json: dict[str, Any], loc: list[str]) -> Any:
        child = json
        for i in loc:
            if i not in child:
                return None
            child = child[i]
        return child

    def appendDoorState(self, data: dict[str, Any]) -> None:
        _LOGGER.debug("APPEND DOOR: Starting to append doors...")
        doors = get_attr(data, "access.accessStatus.value.doors", [])
        tsCarCapturedAccess = get_attr(
            data, "access.accessStatus.value.carCapturedTimestamp"
        )
        _LOGGER.debug(
            "APPEND DOOR: Timestamp captured from car: %s", tsCarCapturedAccess
        )
        for door in doors:
            status = door["status"]
            name = door["name"]
            _LOGGER.debug(
                "APPEND DOOR: Processing door: %s with status: %s", name, status
            )
            if name + "Lock" not in self.OLDAPI_MAPPING:
                _LOGGER.debug(
                    "APPEND DOOR: Skipping door not mapped in OLDAPI_MAPPING: %s", name
                )
                continue
            lock = "0"
            open = "0"
            unsupported = False
            for state in status:
                if state == "unsupported":
                    unsupported = True
                    _LOGGER.debug("APPEND DOOR: Unsupported state for door: %s", name)
                if state == "locked":
                    lock = "2"
                if state == "closed":
                    open = "3"
            if not unsupported:
                doorFieldLock = {
                    "textId": self.OLDAPI_MAPPING[name + "Lock"],
                    "value": lock,
                    "tsCarCaptured": tsCarCapturedAccess,
                }
                _LOGGER.debug(
                    "APPEND DOOR: Appended door lock field: %s", doorFieldLock
                )
                self.data_fields.append(Field(doorFieldLock))

                doorFieldOpen = {
                    "textId": self.OLDAPI_MAPPING[name + "Open"],
                    "value": open,
                    "tsCarCaptured": tsCarCapturedAccess,
                }
                _LOGGER.debug(
                    "APPEND DOOR: Appended door open field: %s", doorFieldOpen
                )
                self.data_fields.append(Field(doorFieldOpen))
        _LOGGER.debug("APPEND DOOR: Finished appending doors")

    def appendWindowState(self, data: dict[str, Any]) -> None:
        _LOGGER.debug("APPEND WINDOW: Starting to append windows...")
        windows = get_attr(data, "access.accessStatus.value.windows", [])
        tsCarCapturedAccess = get_attr(
            data, "access.accessStatus.value.carCapturedTimestamp"
        )
        _LOGGER.debug(
            "APPEND WINDOW: Timestamp captured from car: %s", tsCarCapturedAccess
        )
        for window in windows:
            name = window["name"]
            status = window["status"]
            _LOGGER.debug(
                "APPEND WINDOW: Processing window: %s with status: %s", name, status
            )
            if (
                status[0] == "unsupported"
            ) or name + "Window" not in self.OLDAPI_MAPPING:
                _LOGGER.debug(
                    "APPEND WINDOW: Skipping unsupported window or not mapped in OLDAPI_MAPPING: %s",
                    name,
                )
                continue
            windowField = {
                "textId": self.OLDAPI_MAPPING[name + "Window"],
                "value": "3" if status[0] == "closed" else "0",
                "tsCarCaptured": tsCarCapturedAccess,
            }
            _LOGGER.debug("APPEND WINDOW: Appended window field: %s", windowField)
            self.data_fields.append(Field(windowField))
        _LOGGER.debug("APPEND WINDOW: Finished appending windows")


class TripDataResponse:
    def __init__(self, data: dict[str, Any]) -> None:
        self.data_fields: list[Any] = []

        self.tripID: str = data["tripID"]

        self.averageElectricEngineConsumption: float | None = None
        if "averageElectricEngineConsumption" in data:
            self.averageElectricEngineConsumption = (
                float(data["averageElectricEngineConsumption"]) / 10
            )

        self.averageFuelConsumption: float | None = None
        if "averageFuelConsumption" in data:
            self.averageFuelConsumption = float(data["averageFuelConsumption"]) / 10

        self.averageSpeed: int | None = None
        if "averageSpeed" in data:
            self.averageSpeed = int(data["averageSpeed"])

        self.mileage: int | None = None
        if "mileage" in data:
            self.mileage = int(data["mileage"])

        self.startMileage: int | None = None
        if "startMileage" in data:
            self.startMileage = int(data["startMileage"])

        self.traveltime: int | None = None
        if "traveltime" in data:
            self.traveltime = int(data["traveltime"])

        self.timestamp: str | None = None
        if "timestamp" in data:
            self.timestamp = data["timestamp"]

        self.overallMileage: int | None = None
        if "overallMileage" in data:
            self.overallMileage = int(data["overallMileage"])

        self.zeroEmissionDistance: int | None = None
        if "zeroEmissionDistance" in data:
            self.zeroEmissionDistance = int(data["zeroEmissionDistance"])


class Field:
    IDS: dict[str, str] = {
        "0x0": "UNKNOWN",
        "0x0101010002": "UTC_TIME_AND_KILOMETER_STATUS",
        "0x0203010001": "MAINTENANCE_INTERVAL_DISTANCE_TO_OIL_CHANGE",
        "0x0203010002": "MAINTENANCE_INTERVAL_TIME_TO_OIL_CHANGE",
        "0x0203010003": "MAINTENANCE_INTERVAL_DISTANCE_TO_INSPECTION",
        "0x0203010004": "MAINTENANCE_INTERVAL_TIME_TO_INSPECTION",
        "0x0203010006": "MAINTENANCE_INTERVAL_ALARM_INSPECTION",
        "0x0203010007": "MAINTENANCE_INTERVAL_MONTHLY_MILEAGE",
        "0x0203010005": "WARNING_OIL_CHANGE",
        "0x0204040001": "OIL_LEVEL_AMOUNT_IN_LITERS",
        "0x0204040002": "OIL_LEVEL_MINIMUM_WARNING",
        "0x0204040003": "OIL_LEVEL_DIPSTICKS_PERCENTAGE",
        "0x02040C0001": "ADBLUE_RANGE",
        "0x0301010001": "LIGHT_STATUS",
        "0x0301030001": "BRAKING_STATUS",
        "0x0301030005": "TOTAL_RANGE",
        "0x030103000A": "TANK_LEVEL_IN_PERCENTAGE",
        "0x0301040001": "LOCK_STATE_LEFT_FRONT_DOOR",
        "0x0301040002": "OPEN_STATE_LEFT_FRONT_DOOR",
        "0x0301040003": "SAFETY_STATE_LEFT_FRONT_DOOR",
        "0x0301040004": "LOCK_STATE_LEFT_REAR_DOOR",
        "0x0301040005": "OPEN_STATE_LEFT_REAR_DOOR",
        "0x0301040006": "SAFETY_STATE_LEFT_REAR_DOOR",
        "0x0301040007": "LOCK_STATE_RIGHT_FRONT_DOOR",
        "0x0301040008": "OPEN_STATE_RIGHT_FRONT_DOOR",
        "0x0301040009": "SAFETY_STATE_RIGHT_FRONT_DOOR",
        "0x030104000A": "LOCK_STATE_RIGHT_REAR_DOOR",
        "0x030104000B": "OPEN_STATE_RIGHT_REAR_DOOR",
        "0x030104000C": "SAFETY_STATE_RIGHT_REAR_DOOR",
        "0x030104000D": "LOCK_STATE_TRUNK_LID",
        "0x030104000E": "OPEN_STATE_TRUNK_LID",
        "0x030104000F": "SAFETY_STATE_TRUNK_LID",
        "0x0301040010": "LOCK_STATE_HOOD",
        "0x0301040011": "OPEN_STATE_HOOD",
        "0x0301040012": "SAFETY_STATE_HOOD",
        "0x0301050001": "STATE_LEFT_FRONT_WINDOW",
        "0x0301050003": "STATE_LEFT_REAR_WINDOW",
        "0x0301050005": "STATE_RIGHT_FRONT_WINDOW",
        "0x0301050007": "STATE_RIGHT_REAR_WINDOW",
        "0x0301050009": "STATE_DECK",
        "0x030105000B": "STATE_SUN_ROOF_MOTOR_COVER",
        "0x0301030006": "PRIMARY_RANGE",
        "0x0301030007": "PRIMARY_DRIVE",
        "0x0301030008": "SECONDARY_RANGE",
        "0x0301030009": "SECONDARY_DRIVE",
        "0x0301030002": "STATE_OF_CHARGE",
        "0x0301020001": "TEMPERATURE_OUTSIDE",
        "0x0202": "ACTIVE_INSTRUMENT_CLUSTER_WARNING",
    }

    def __init__(self, data: dict[str, Any]) -> None:
        self.name: str | None = None
        self.id: str | None = data.get("id")
        self.unit: str | None = data.get("unit")
        self.value: Any = data.get("value")
        self.measure_time: str | None = data.get("tsTssReceivedUtc")
        if self.measure_time is None:
            self.measure_time = data.get("tsCarCaptured")
        self.send_time: str | None = data.get("tsCarSentUtc")
        self.measure_mileage: Any = data.get("milCarCaptured")
        self.send_mileage: Any = data.get("milCarSent")

        for field_id, name in self.IDS.items():
            if field_id == self.id:
                self.name = name
                break
        if self.name is None:
            # No direct mapping found - maybe we've at least got a text id
            self.name = data.get("textId")

    def __str__(self) -> str:
        str_rep = str(self.name) + " " + str(self.value)
        if self.unit is not None:
            str_rep += self.unit
        return str_rep


class Vehicle:
    def __init__(self) -> None:
        self.vin: str = ""
        self.csid: str = ""
        self.model: str = ""
        self.model_source: str = "unavailable"
        self.model_year: str = ""
        self.model_family: str = ""
        self.title: str = ""

    @staticmethod
    def _clean_label(value: Any) -> str:
        """Accept a non-blank Audi string, never the literal None or object."""
        return value.strip() if isinstance(value, str) else ""

    def parse(self, data: dict[str, Any]) -> None:
        self.vin = data.get("vin") or ""
        self.csid = data.get("csid") or ""
        vehicle = data.get("vehicle") or {}
        if not isinstance(vehicle, dict):
            vehicle = {}
        media = vehicle.get("media") or {}
        if not isinstance(media, dict):
            media = {}
        core = vehicle.get("core") or {}
        if not isinstance(core, dict):
            core = {}

        # Auth0 GraphQL returns a nonfatal enrichment error on some cars;
        # media.longName is then absent. shortName is still manufacturer data.
        long_name = self._clean_label(media.get("longName"))
        short_name = self._clean_label(media.get("shortName"))
        nickname = self._clean_label(data.get("nickname"))
        if long_name:
            self.model, self.model_source = long_name, "audi_long_name"
        elif short_name:
            self.model, self.model_source = short_name, "audi_short_name"
        elif nickname:
            # Last resort: a user-defined vehicle label, NOT a verified model.
            self.model, self.model_source = nickname, "nickname_fallback"
        else:
            self.model, self.model_source = "", "unavailable"

        year = core.get("modelYear")
        self.model_year = str(year) if year is not None and str(year).strip() else ""
        self.title = nickname or short_name or long_name or "Audi vehicle"

    def __str__(self) -> str:
        return str(self.__dict__)


class VehiclesResponse:
    def __init__(self) -> None:
        self.vehicles: list[Vehicle] = []
        self.blacklisted_vins: int = 0

    def parse(self, data: dict[str, Any]) -> None:
        user_vehicles = data.get("userVehicles")
        if user_vehicles is None:
            _LOGGER.warning("No vehicle data received from API. Check authentication.")
            return

        for item in user_vehicles:
            vehicle = Vehicle()
            vehicle.parse(item)
            self.vehicles.append(vehicle)


__all__ = [
    "CurrentVehicleDataResponse",
    "Field",
    "TripDataResponse",
    "Vehicle",
    "VehicleData",
    "VehicleDataResponse",
    "VehiclesResponse",
]
