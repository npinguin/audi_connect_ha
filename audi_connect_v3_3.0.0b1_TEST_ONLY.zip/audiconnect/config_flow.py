from __future__ import annotations

import base64
import logging
import secrets
from collections.abc import Mapping
from hashlib import sha256
from typing import Any
from urllib.parse import parse_qs, urlparse

import voluptuous as vol
from homeassistant.config_entries import (
    ConfigEntry,
    ConfigFlow,
    ConfigFlowResult,
    OptionsFlow,
)
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.selector import (
    NumberSelector,
    NumberSelectorConfig,
    SelectSelector,
    SelectSelectorConfig,
    SelectSelectorMode,
    TextSelector,
    TextSelectorConfig,
    TextSelectorType,
)

from .audi_connect_account import AudiConnectAccount
from .audi_services import AudiAuthError, AudiTokenRefreshError
from .local_extensions import (
    DEALER_FIELDS,
    get_local_dealer,
    update_local_dealer_options,
)
from .const import (
    API_LEVELS,
    AUTH0_REDIRECT_URI,
    CONF_API_LEVEL,
    CONF_FILTER_VINS,
    CONF_PASSWORD,
    CONF_REFRESH_AFTER_ACTION,
    CONF_REFRESH_TOKEN,
    CONF_REGION,
    CONF_SCAN_INITIAL,
    CONF_SCAN_INTERVAL,
    CONF_SPIN,
    CONF_UPDATE_SLEEP,
    CONF_USERNAME,
    DEFAULT_API_LEVEL,
    DEFAULT_UPDATE_INTERVAL,
    DOMAIN,
    MIN_UPDATE_INTERVAL,
    REGIONS,
    UPDATE_SLEEP,
    entry_uses_auth0,
    uses_auth0,
)

_LOGGER = logging.getLogger(__name__)

REGION_OPTIONS = {str(k): v for k, v in REGIONS.items()}
REGION_REVERSE = {v: k for k, v in REGIONS.items()}
CONF_CALLBACK_URL = "callback_url"


def _generate_auth0_pkce() -> tuple[str, str, str]:
    """Return a PKCE verifier, challenge and OAuth state."""
    verifier = secrets.token_urlsafe(48)
    digest = sha256(verifier.encode()).digest()
    challenge = base64.urlsafe_b64encode(digest).decode().rstrip("=")
    return verifier, challenge, secrets.token_urlsafe(24)


def _parse_auth0_callback(callback_url: str, expected_state: str) -> str:
    """Validate a myAudi callback and return its authorization code."""
    parsed = urlparse(callback_url.strip())
    expected = urlparse(AUTH0_REDIRECT_URI)
    params = parse_qs(parsed.query)
    if (
        parsed.scheme,
        parsed.hostname,
        parsed.port,
        parsed.path,
    ) != (
        expected.scheme,
        expected.hostname,
        expected.port,
        expected.path,
    ):
        raise ValueError("invalid_auth0_callback")
    if params.get("error"):
        raise ValueError("auth0_denied")
    state = (params.get("state") or [None])[0]
    code = (params.get("code") or [None])[0]
    if not state or not secrets.compare_digest(state, expected_state) or not code:
        raise ValueError("invalid_auth0_callback")
    return code


class AudiConfigFlow(ConfigFlow, domain=DOMAIN):
    VERSION = 3

    def __init__(self) -> None:
        self._flow_data: dict[str, Any] = {}
        self._connection: AudiConnectAccount | None = None
        self._device_code: str | None = None
        self._verification_uri: str | None = None
        self._user_code: str | None = None
        self._auth0_verifier: str | None = None
        self._auth0_state: str | None = None
        self._auth0_authorization_url: str | None = None
        self._reauth_entry: ConfigEntry | None = None

    def _build_connection(
        self, username: str | None = None, password: str | None = None
    ) -> AudiConnectAccount:
        session = async_get_clientsession(self.hass)
        return AudiConnectAccount(
            session=session,
            country=self._flow_data[CONF_REGION],
            spin=self._flow_data.get(CONF_SPIN),
            api_level=self._flow_data.get(CONF_API_LEVEL, DEFAULT_API_LEVEL),
            username=username,
            password=password,
        )

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        if user_input is not None:
            self._flow_data = {
                CONF_REGION: REGION_OPTIONS[user_input[CONF_REGION]],
                CONF_SPIN: user_input.get(CONF_SPIN),
                CONF_API_LEVEL: int(user_input[CONF_API_LEVEL]),
                CONF_SCAN_INTERVAL: max(
                    int(user_input.get(CONF_SCAN_INTERVAL, DEFAULT_UPDATE_INTERVAL)),
                    MIN_UPDATE_INTERVAL,
                ),
            }
            if uses_auth0(self._flow_data[CONF_REGION]):
                return await self.async_step_auth0()
            return await self.async_step_credentials()

        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema(
                {
                    vol.Optional(CONF_SPIN): str,
                    vol.Required(CONF_REGION, default="1"): SelectSelector(
                        SelectSelectorConfig(
                            options=[
                                {"value": k, "label": v}
                                for k, v in REGION_OPTIONS.items()
                            ],
                            mode=SelectSelectorMode.DROPDOWN,
                        )
                    ),
                    vol.Required(
                        CONF_SCAN_INTERVAL, default=DEFAULT_UPDATE_INTERVAL
                    ): NumberSelector(
                        NumberSelectorConfig(min=MIN_UPDATE_INTERVAL, mode="box")
                    ),
                    vol.Required(
                        CONF_API_LEVEL, default=str(API_LEVELS[DEFAULT_API_LEVEL])
                    ): SelectSelector(
                        SelectSelectorConfig(
                            options=[str(level) for level in API_LEVELS],
                            mode=SelectSelectorMode.DROPDOWN,
                        )
                    ),
                }
            ),
        )

    async def async_step_credentials(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Username/password sign-in, for regions without attestation."""
        errors: dict[str, str] = {}

        if user_input is not None:
            username = user_input[CONF_USERNAME]
            password = user_input[CONF_PASSWORD]
            connection = self._build_connection(username, password)
            try:
                if await connection.try_login(False):
                    return await self._finish_password_login(username, password)
                errors["base"] = "invalid_credentials"
            except AudiAuthError:
                errors["base"] = "invalid_credentials"
            except Exception:
                _LOGGER.exception("Audi password login failed")
                errors["base"] = "unexpected"

        step_id = (
            "reauth_credentials" if self._reauth_entry is not None else "credentials"
        )
        return self.async_show_form(
            step_id=step_id,
            data_schema=vol.Schema(
                {
                    vol.Required(
                        CONF_USERNAME,
                        default=(user_input or {}).get(CONF_USERNAME, ""),
                    ): str,
                    vol.Required(CONF_PASSWORD): TextSelector(
                        TextSelectorConfig(type=TextSelectorType.PASSWORD)
                    ),
                }
            ),
            errors=errors,
        )

    async def _finish_password_login(
        self, username: str, password: str
    ) -> ConfigFlowResult:
        """Persist a username/password entry (or update it on reauth)."""
        if self._reauth_entry is not None:
            # Schedule the reload ourselves: async_update_reload_and_abort is
            # deprecated (HA 2026.12) for entries that register an update
            # listener, which this integration does.
            self.hass.config_entries.async_schedule_reload(self._reauth_entry.entry_id)
            return self.async_update_and_abort(
                self._reauth_entry,
                data={
                    **self._reauth_entry.data,
                    CONF_USERNAME: username,
                    CONF_PASSWORD: password,
                },
            )

        await self.async_set_unique_id(username.lower())
        self._abort_if_unique_id_configured()
        return self.async_create_entry(
            title=username,
            data={
                **self._flow_data,
                CONF_USERNAME: username,
                CONF_PASSWORD: password,
            },
        )

    async def async_step_auth0(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Interactive Auth0 login using the myAudi PKCE client."""
        errors: dict[str, str] = {}
        if self._connection is None:
            self._connection = self._build_connection()

        if self._auth0_authorization_url is None:
            verifier, challenge, state = _generate_auth0_pkce()
            try:
                authorization_url = await self._connection.get_auth0_authorization_url(
                    challenge, state
                )
            except Exception:
                _LOGGER.exception("Audi Auth0 authorization failed")
                return self.async_abort(reason="auth0_auth_failed")
            self._auth0_verifier = verifier
            self._auth0_state = state
            self._auth0_authorization_url = authorization_url

        if user_input is not None:
            assert self._auth0_state is not None
            assert self._auth0_verifier is not None
            try:
                code = _parse_auth0_callback(
                    user_input[CONF_CALLBACK_URL], self._auth0_state
                )
            except ValueError as err:
                errors["base"] = str(err)
            else:
                try:
                    await self._connection.login_with_auth0_code(
                        code, self._auth0_verifier
                    )
                except (AudiAuthError, AudiTokenRefreshError):
                    errors["base"] = "auth0_auth_failed"
                except Exception:
                    _LOGGER.exception("Audi Auth0 token exchange failed")
                    errors["base"] = "unexpected"
                else:
                    return await self._finish_token_login()

        step_id = "reauth_auth0" if self._reauth_entry is not None else "auth0"
        return self.async_show_form(
            step_id=step_id,
            data_schema=vol.Schema(
                {
                    vol.Required(
                        CONF_CALLBACK_URL,
                        default=(user_input or {}).get(CONF_CALLBACK_URL, ""),
                    ): TextSelector()
                }
            ),
            description_placeholders={
                "authorization_url": self._auth0_authorization_url or ""
            },
            errors=errors,
        )

    async def async_step_device(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Device Authorization Grant: show a code/URL, then poll for approval."""
        errors: dict[str, str] = {}

        if self._connection is None:
            self._connection = self._build_connection()

        if self._device_code is None:
            try:
                response = await self._connection.request_device_code()
            except Exception:
                _LOGGER.exception("Audi device authorization request failed")
                return self.async_abort(reason="device_auth_failed")
            self._device_code = response["device_code"]
            self._verification_uri = response.get(
                "verification_uri_complete"
            ) or response.get("verification_uri")
            self._user_code = response.get("user_code")

        if user_input is not None:
            try:
                status = await self._connection.poll_device_token(self._device_code)
            except Exception:
                _LOGGER.exception("Audi device token poll failed")
                status = None
                errors["base"] = "device_auth_failed"
            if status == "ok":
                return await self._finish_token_login()
            if status in ("authorization_pending", "slow_down"):
                errors["base"] = "authorization_pending"
            elif status == "expired":
                # Code timed out; mint a fresh one and show it again.
                self._device_code = None
                return await self.async_step_device()
            elif status is not None:
                errors["base"] = "device_auth_failed"

        step_id = "reauth_confirm" if self._reauth_entry is not None else "device"
        return self.async_show_form(
            step_id=step_id,
            data_schema=vol.Schema({}),
            description_placeholders={
                "verification_uri": self._verification_uri or "",
                "user_code": self._user_code or "",
            },
            errors=errors,
        )

    async def _finish_token_login(self) -> ConfigFlowResult:
        assert self._connection is not None
        refresh_token = self._connection.refresh_token
        if not refresh_token:
            # Approved but no refresh token issued; do not persist a dead entry.
            return self.async_abort(reason="device_auth_failed")

        if self._reauth_entry is not None:
            # Schedule the reload ourselves (see _finish_password_login). A
            # token reauth only changes the refresh token, which the
            # update listener deliberately ignores, so the reload has to be
            # scheduled here explicitly.
            self.hass.config_entries.async_schedule_reload(self._reauth_entry.entry_id)
            return self.async_update_and_abort(
                self._reauth_entry,
                data={
                    **self._reauth_entry.data,
                    CONF_REFRESH_TOKEN: refresh_token,
                },
            )

        identifier = self._connection.account_identifier()
        if identifier:
            await self.async_set_unique_id(identifier.lower())
            self._abort_if_unique_id_configured()
        return self.async_create_entry(
            title=identifier or "Audi Connect",
            data={**self._flow_data, CONF_REFRESH_TOKEN: refresh_token},
        )

    async def async_step_reauth(
        self, entry_data: Mapping[str, Any]
    ) -> ConfigFlowResult:
        self._reauth_entry = self._get_reauth_entry()
        self._flow_data = {
            CONF_REGION: self._reauth_entry.data.get(CONF_REGION),
            CONF_SPIN: self._reauth_entry.data.get(CONF_SPIN),
            CONF_API_LEVEL: self._reauth_entry.data.get(
                CONF_API_LEVEL, DEFAULT_API_LEVEL
            ),
        }
        return await self.async_step_reauth_confirm()

    async def async_step_reauth_confirm(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        assert self._reauth_entry is not None
        if entry_uses_auth0(self._reauth_entry.data):
            return await self.async_step_auth0(user_input)
        return await self.async_step_credentials(user_input)

    async def async_step_reauth_credentials(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Reauth form id for the credentials path (see async_step_credentials)."""
        return await self.async_step_credentials(user_input)

    async def async_step_reauth_auth0(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Reauth form id for the Auth0 path."""
        return await self.async_step_auth0(user_input)

    async def async_step_reconfigure(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        reconfigure_entry = self._get_reconfigure_entry()

        if user_input is not None:
            # Schedule the reload ourselves (see _finish_password_login).
            self.hass.config_entries.async_schedule_reload(reconfigure_entry.entry_id)
            return self.async_update_and_abort(
                reconfigure_entry,
                data_updates={
                    CONF_SPIN: user_input.get(CONF_SPIN),
                    CONF_REGION: REGION_OPTIONS[user_input[CONF_REGION]],
                    CONF_API_LEVEL: int(user_input[CONF_API_LEVEL]),
                },
            )

        current_region = reconfigure_entry.data.get(CONF_REGION, "DE")
        current_region_key = str(REGION_REVERSE.get(current_region, 1))

        return self.async_show_form(
            step_id="reconfigure",
            # 2.2.0 interpolated {username} into the reconfigure description.
            # A browser session from before the update still has that string
            # cached, and rendering it without the value fails hard (formatjs
            # MISSING_VALUE), leaving an empty dialog. Keep providing it.
            description_placeholders={"username": reconfigure_entry.title},
            data_schema=vol.Schema(
                {
                    vol.Optional(
                        CONF_SPIN,
                        # The S-PIN is optional, and an entry created without one
                        # stores None (not a missing key), so the "" fallback of
                        # .get() never applies. Coerce it, or the str validator
                        # rejects the default with "expected str".
                        default=reconfigure_entry.data.get(CONF_SPIN) or "",
                    ): str,
                    vol.Required(
                        CONF_REGION, default=current_region_key
                    ): SelectSelector(
                        SelectSelectorConfig(
                            options=[
                                {"value": k, "label": v}
                                for k, v in REGION_OPTIONS.items()
                            ],
                            mode=SelectSelectorMode.DROPDOWN,
                        )
                    ),
                    vol.Required(
                        CONF_API_LEVEL,
                        default=str(
                            reconfigure_entry.data.get(
                                CONF_API_LEVEL, API_LEVELS[DEFAULT_API_LEVEL]
                            )
                        ),
                    ): SelectSelector(
                        SelectSelectorConfig(
                            options=[str(level) for level in API_LEVELS],
                            mode=SelectSelectorMode.DROPDOWN,
                        )
                    ),
                }
            ),
        )

    @staticmethod
    def async_get_options_flow(config_entry: ConfigEntry) -> OptionsFlowHandler:
        return OptionsFlowHandler()


class OptionsFlowHandler(OptionsFlow):
    """Configure polling and optional per-vehicle, local dealer details."""

    _pending_options: dict[str, Any] | None = None
    _dealer_vin: str | None = None

    def _dealer_vehicles(self) -> list[tuple[str, str]]:
        """Vehicles already loaded in this account; no extra Audi API request."""
        runtime = getattr(self.config_entry, "runtime_data", None)
        items: list[tuple[str, str]] = []
        for config_vehicle in getattr(
            getattr(runtime, "account", None), "config_vehicles", []
        ):
            vehicle = getattr(config_vehicle, "vehicle", None)
            vin = getattr(vehicle, "vin", None)
            if not isinstance(vin, str) or not vin:
                continue
            name = (
                getattr(vehicle, "title", None)
                or getattr(vehicle, "model", None)
                or "Audi"
            )
            items.append((vin, f"{name} (…{vin[-4:]})"))
        return items

    async def async_step_dealer_vehicle(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        vehicles = self._dealer_vehicles()
        if not vehicles:
            return self.async_abort(reason="no_vehicle_available")
        if len(vehicles) == 1:
            self._dealer_vin = vehicles[0][0]
            return await self.async_step_dealer()
        if user_input is not None:
            vin = user_input.get("vehicle")
            if vin not in {key for key, _ in vehicles}:
                return self.async_show_form(
                    step_id="dealer_vehicle",
                    data_schema=vol.Schema(
                        {vol.Required("vehicle"): vol.In(dict(vehicles))}
                    ),
                    errors={"base": "invalid_vehicle"},
                )
            self._dealer_vin = vin
            return await self.async_step_dealer()
        return self.async_show_form(
            step_id="dealer_vehicle",
            data_schema=vol.Schema(
                {
                    vol.Required("vehicle", default=vehicles[0][0]): SelectSelector(
                        SelectSelectorConfig(
                            options=[
                                {"value": vin, "label": label}
                                for vin, label in vehicles
                            ],
                            mode=SelectSelectorMode.DROPDOWN,
                        )
                    ),
                }
            ),
        )

    async def async_step_dealer(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        vin = self._dealer_vin
        if not vin:
            return await self.async_step_dealer_vehicle()
        pending = self._pending_options or dict(self.config_entry.options)
        errors: dict[str, str] = {}
        if user_input is not None:
            updates = {
                key: user_input[key] for key in DEALER_FIELDS if key in user_input
            }
            try:
                options = update_local_dealer_options(
                    pending, vin, updates, clear=bool(user_input.get("clear", False))
                )
            except ValueError:
                errors["base"] = "invalid_dealer"
            else:
                return self.async_create_entry(title="", data=options)
        existing = get_local_dealer(pending, vin)
        data_schema = vol.Schema(
            {
                **{
                    vol.Optional(
                        key,
                        default=(
                            user_input.get(key, existing.get(key, ""))
                            if user_input is not None
                            else existing.get(key, "")
                        ),
                    ): TextSelector()
                    for key in DEALER_FIELDS
                },
                vol.Optional("clear", default=False): bool,
            }
        )
        return self.async_show_form(
            step_id="dealer", data_schema=data_schema, errors=errors
        )

    async def async_step_init(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        if user_input is not None:
            user_input = dict(user_input)
            user_input.setdefault("runtime_version", "v2")
            user_input.setdefault("v3_climate_start_route", "auto")
            user_input.setdefault("v3_climate_status_route", "auto")
            user_input.setdefault("v3_climate_experimental_unknown", False)
            edit_dealer = bool(user_input.pop("edit_local_dealer", False))
            user_input[CONF_SCAN_INTERVAL] = max(
                int(user_input[CONF_SCAN_INTERVAL]), MIN_UPDATE_INTERVAL
            )
            # OptionsFlow replaces all options; preserve per-vehicle metadata.
            if "local_dealers" in self.config_entry.options:
                user_input["local_dealers"] = self.config_entry.options["local_dealers"]
            if edit_dealer:
                self._pending_options = user_input
                return await self.async_step_dealer_vehicle()
            return self.async_create_entry(title="", data=user_input)

        return self.async_show_form(
            step_id="init",
            data_schema=vol.Schema(
                {
                    vol.Optional("edit_local_dealer", default=False): bool,
                    vol.Required(
                        "runtime_version",
                        default=self.config_entry.options.get("runtime_version", "v2"),
                    ): vol.In(("v2", "v3_climate")),
                    vol.Required(
                        "v3_climate_start_route",
                        default=self.config_entry.options.get(
                            "v3_climate_start_route", "auto"
                        ),
                    ): vol.In((
                        "auto",
                        "cariad.climate.start.stored",
                        "cariad.climate.start.vehicle_settings",
                    )),
                    vol.Required(
                        "v3_climate_experimental_unknown",
                        default=self.config_entry.options.get(
                            "v3_climate_experimental_unknown", False
                        ),
                    ): bool,
                    vol.Required(
                        "v3_climate_status_route",
                        default=self.config_entry.options.get(
                            "v3_climate_status_route", "auto"
                        ),
                    ): vol.In(("auto", "cariad.climate.status.batch")),
                    vol.Required(
                        CONF_SCAN_INITIAL,
                        default=self.config_entry.options.get(CONF_SCAN_INITIAL, True),
                    ): bool,
                    vol.Required(
                        "climate_quick_start",
                        default=self.config_entry.options.get(
                            "climate_quick_start", False
                        ),
                    ): bool,
                    vol.Required(
                        "experimental_commands",
                        default=self.config_entry.options.get(
                            "experimental_commands", False
                        ),
                    ): bool,
                    vol.Required(
                        CONF_REFRESH_AFTER_ACTION,
                        default=self.config_entry.options.get(
                            CONF_REFRESH_AFTER_ACTION, False
                        ),
                    ): bool,
                    vol.Required(
                        CONF_UPDATE_SLEEP,
                        default=self.config_entry.options.get(
                            CONF_UPDATE_SLEEP, UPDATE_SLEEP
                        ),
                    ): NumberSelector(NumberSelectorConfig(min=0, mode="box")),
                    vol.Required(
                        CONF_SCAN_INTERVAL,
                        default=self.config_entry.options.get(
                            CONF_SCAN_INTERVAL,
                            self.config_entry.data.get(
                                CONF_SCAN_INTERVAL, DEFAULT_UPDATE_INTERVAL
                            ),
                        ),
                    ): NumberSelector(
                        NumberSelectorConfig(min=MIN_UPDATE_INTERVAL, mode="box")
                    ),
                    vol.Optional(
                        CONF_FILTER_VINS,
                        default=self.config_entry.options.get(
                            CONF_FILTER_VINS,
                            self.config_entry.data.get(CONF_FILTER_VINS, ""),
                        ),
                    ): TextSelector(),
                }
            ),
        )


__all__ = ["AudiConfigFlow", "OptionsFlowHandler"]
